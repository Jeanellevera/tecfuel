<?php 
session_start();
if (isset($_SESSION['role']) && isset($_SESSION['id']) && $_SESSION['role'] == "admin") {
    include "DB_connection.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Reports</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- ✅ Core Styles -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">

  <!-- ✅ DataTables Export Buttons -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.bootstrap5.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    body {
        background: #f4f6fa;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    h3 {
        font-weight: 700;
        color: #1a1a1a;
        margin-bottom: 25px;
    }

    /* 🔹 Report Buttons Row */
    .report-buttons {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        margin-bottom: 20px;
    }
    .report-buttons button {
        flex: 1 1 180px;
        font-weight: 600;
        border-radius: 6px;
        padding: 10px;
        transition: 0.2s ease-in-out;
        border: 1px solid #ccc;
    }
    .report-buttons button:hover {
        transform: scale(1.02);
    }
    .report-buttons .btn.active {
        color: #fff !important;
        box-shadow: 0 0 6px rgba(0,0,0,0.2);
    }

    /* 🔹 Report Container */
    #reportContainer {
        background: #fff;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        min-height: 450px;
        overflow-x: auto;
    }

    /* 🔹 Placeholder Style */
    #reportContainer p {
        color: #666;
        font-size: 15px;
    }

    /* 🔹 Scroll fix for narrow screens */
    @media (max-width: 768px) {
        .report-buttons button {
            flex: 1 1 100%;
        }
    }
  </style>
</head>
<body>
  <input type="checkbox" id="checkbox">
  <?php include "inc/header.php"; ?>

  <div class="body">
    <?php include "inc/nav.php"; ?>

    <section class="section-1">
      <div class="container-fluid mt-3">
        <h3 class="mb-4"><i class="fa fa-pie-chart text-primary me-2"></i>Admin Reports</h3>

        <!-- 🔹 Report Selector -->
        <div class="report-buttons">
          <button class="btn btn-outline-primary" data-report="pending">
            <i class="fa fa-clock me-1"></i> Pending Days
          </button>
          <button class="btn btn-outline-success" data-report="labor">
            <i class="fa fa-briefcase me-1"></i> Labor Hours
          </button>
          <button class="btn btn-outline-info" data-report="parts">
            <i class="fa fa-cogs me-1"></i> Parts Usage
          </button>
        </div>

        <!-- 🔹 Report Output Container -->
        <div id="reportContainer" class="text-center py-5">
          <i class="fa fa-line-chart fa-2x mb-2 text-secondary"></i>
          <p>Select a report type above to view detailed records.</p>
        </div>
      </div>
    </section>
  </div>

  <!-- ✅ Core Scripts -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <!-- ✅ DataTables Scripts -->
  <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.bootstrap5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

  <!-- ✅ Report Loader -->
  <script>
  $(function() {
      $(".report-buttons button").click(function() {
          $(".report-buttons button")
              .removeClass("active btn-primary btn-success btn-info")
              .addClass("btn-outline-primary");

          const type = $(this).data("report");
          let file = "";

          if (type === "pending") {
              $(this).removeClass("btn-outline-primary").addClass("btn-primary active");
              file = "admin_pending_report.php";
          } else if (type === "labor") {
              $(this).removeClass("btn-outline-primary").addClass("btn-success active");
              file = "admin_labor_report.php";
          } else if (type === "parts") {
              $(this).removeClass("btn-outline-primary").addClass("btn-info active");
              file = "admin_parts_report.php";
          }

          $("#reportContainer").html("<p class='text-center text-muted py-5'><i class='fa fa-spinner fa-spin fa-2x'></i><br>Loading report...</p>");
          $("#reportContainer").load(file);
      });
  });
  </script>
</body>
</html>

<?php 
} else { 
   header("Location: login.php?error=Unauthorized Access");
   exit();
}
?>
