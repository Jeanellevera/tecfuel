<?php
include "DB_connection.php";

$from = $_GET['from'] ?? date('Y-m-d', strtotime('monday this week'));
$to   = $_GET['to']   ?? date('Y-m-d', strtotime('saturday this week'));

$stmt = $conn->prepare("
  SELECT ws.total_minutes, u.full_name AS mechanic_name
  FROM work_sessions ws
  LEFT JOIN users u ON ws.mechanic_id = u.id
  WHERE DATE(ws.work_start) BETWEEN ? AND ?
");
$stmt->execute([$from, $to]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalMinutes = array_sum(array_column($rows, 'total_minutes'));
$totalHours = round($totalMinutes / 60, 2);
$mechanics = array_unique(array_column($rows, 'mechanic_name'));
$totalMechanics = count($mechanics);
$avgPerMechanic = $totalMechanics > 0 ? round($totalHours / $totalMechanics, 2) : 0;

header('Content-Type: application/json');
echo json_encode([
  'total_hours' => $totalHours,
  'mechanics' => $totalMechanics,
  'avg_per_mechanic' => $avgPerMechanic
]);
?>
