<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
  header("Location: login.php");
  exit();
}
include "DB_connection.php";

/* ----------------------------
   🔹 FETCH ALL WORK SESSIONS (including Request Item, Inspection, etc.)
----------------------------- */
$sql = "
  SELECT 
    ws.session_id,
    ws.wor_id,
    ws.mechanic_id,
    ws.activity,
    ws.work_start,
    ws.work_end,
    ws.status,
    ws.remarks,
    ws.updated_at,
    u.full_name AS mechanic_name,
    COALESCE(wo.wor_number, 'N/A') AS wor_number,
    COALESCE(wo.tanker_code, 'N/A') AS tanker_code,
    COALESCE(wo.plate_no, '') AS plate_no,
    COALESCE(wo.symptoms, '') AS symptoms,
    COALESCE(wo.urgency, '') AS urgency,
    COALESCE(wo.status, 'Pending') AS wor_status,
    COALESCE(d.full_name, '—') AS driver_name,

    /* ✅ Total Minutes Calculation with Break Deductions (if both times exist) */
    CASE 
      WHEN ws.work_start IS NOT NULL AND ws.work_end IS NOT NULL THEN 
        GREATEST(
          TIMESTAMPDIFF(MINUTE, ws.work_start, ws.work_end)
          /* Morning Break: 10:00–10:15 */
          - IF(TIME(ws.work_start) < '10:15:00' AND TIME(ws.work_end) > '10:00:00', 15, 0)
          /* Lunch Break: 12:00–13:00 */
          - IF(TIME(ws.work_start) < '13:00:00' AND TIME(ws.work_end) > '12:00:00', 60, 0)
          /* Afternoon Break: 15:00–15:15 */
          - IF(TIME(ws.work_start) < '15:15:00' AND TIME(ws.work_end) > '15:00:00', 15, 0),
          0
        )
      ELSE 0
    END AS total_minutes

  FROM work_sessions ws
  LEFT JOIN users u ON ws.mechanic_id = u.id
  LEFT JOIN work_orders wo ON ws.wor_id = wo.id
  LEFT JOIN users d ON wo.driver_id = d.id
  /* ✅ Include all sessions, even without start/end time */
  WHERE ws.wor_id IS NOT NULL
  ORDER BY wo.wor_number ASC, ws.updated_at DESC
";

$stmt = $conn->prepare($sql);
$stmt->execute();
$sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);


/* ----------------------------
   🔹 TOTAL DURATION PER WORK ORDER SUMMARY
----------------------------- */
$sql_total = "
  SELECT 
    wo.id AS wor_id,
    wo.wor_number,
    wo.tanker_code,
    GROUP_CONCAT(DISTINCT u.full_name SEPARATOR ', ') AS mechanic_name,

    /* ✅ Total Duration (sum only sessions that have time values) */
    SUM(
      CASE 
        WHEN ws.work_start IS NOT NULL AND ws.work_end IS NOT NULL THEN 
          GREATEST(
            TIMESTAMPDIFF(MINUTE, ws.work_start, ws.work_end)
            - IF(TIME(ws.work_start) < '10:15:00' AND TIME(ws.work_end) > '10:00:00', 15, 0)
            - IF(TIME(ws.work_start) < '13:00:00' AND TIME(ws.work_end) > '12:00:00', 60, 0)
            - IF(TIME(ws.work_start) < '15:15:00' AND TIME(ws.work_end) > '15:00:00', 15, 0),
            0
          )
        ELSE 0
      END
    ) AS total_duration,

    COUNT(ws.session_id) AS session_count,

    (
      SELECT ws2.status 
      FROM work_sessions ws2 
      WHERE ws2.wor_id = wo.id 
      ORDER BY ws2.session_id DESC 
      LIMIT 1
    ) AS overall_status

  FROM work_sessions ws
  LEFT JOIN work_orders wo ON ws.wor_id = wo.id
  LEFT JOIN users u ON ws.mechanic_id = u.id
  WHERE ws.wor_id IS NOT NULL
  GROUP BY wo.id, wo.wor_number, wo.tanker_code
  ORDER BY total_duration DESC
";

$stmt_total = $conn->prepare($sql_total);
$stmt_total->execute();
$totals = $stmt_total->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Work Sessions | Motorpool Admin</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="css/style.css">
  <style>
    body { background-color: #f4f6fa; }
    .section-1 { padding: 20px; }
    .card-header h5 { margin: 0; }

    #workSessionTable th, #workSessionTable td,
    #summaryTable th, #summaryTable td {
      text-align: center !important;
      vertical-align: middle !important;
    }

    .badge { font-size: 0.85rem; }

    .modal-header.bg-success {
      background-color: #28a745 !important;
      color: #fff !important;
      border-top-left-radius: 8px;
      border-top-right-radius: 8px;
    }

    .modal-header .close {
      color: #fff !important;
      font-size: 1.8rem;
      opacity: 1;
      line-height: 1;
    }
  </style>
</head>
<body>

<input type="checkbox" id="checkbox">
<?php include "inc/header.php"; ?>
<div class="body">
  <?php include "inc/nav.php"; ?>

  <section class="section-1">
    <div class="container-fluid mt-3">

      <!-- 🔹 INDIVIDUAL SESSIONS -->
      <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
          <h5 class="mb-0"><i class="fa fa-clock"></i> Work Sessions Overview</h5>
          <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#summaryModal">
            <i class="fa fa-hourglass-half"></i> View Summary
          </button>
        </div>

        <div class="card-body">
          <div class="table-responsive">
            <table id="workSessionTable" class="table table-striped table-bordered table-hover w-100">
              <thead class="thead-dark">
                <tr>
                  <th>Session ID</th>
                  <th>Mechanic</th>
                  <th>WOR #</th>
                  <th>Driver</th>
                  <th>Tanker Code</th>
                  <th>Activity</th>
                  <th>Start Time</th>
                  <th>End Time</th>
                  <th>Total (HH:MM)</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($sessions as $s): ?>
                  <?php
                    $mins = (int)($s['total_minutes'] ?? 0);
                    $h = floor($mins / 60);
                    $m = $mins % 60;
                    $formattedDuration = sprintf("%02d:%02d", $h, $m);
                  ?>
                  <tr>
                    <td><?= $s['session_id'] ?></td>
                    <td><?= htmlspecialchars($s['mechanic_name']) ?></td>
                    <td><?= htmlspecialchars($s['wor_number']) ?></td>
                    <td><?= htmlspecialchars($s['driver_name']) ?></td>
                    <td><?= htmlspecialchars($s['tanker_code']) ?></td>
                    <td><?= htmlspecialchars($s['activity']) ?></td>
                    <td><?= $s['work_start'] ? date("M d, Y • h:i A", strtotime($s['work_start'])) : '' ?></td>
                    <td>
                      <?php 
                        if (!empty($s['work_end']) && $s['work_end'] !== '0000-00-00 00:00:00') {
                          echo date("M d, Y • h:i A", strtotime($s['work_end']));
                        } else {
                          echo ''; // show blank if no valid end time
                        }
                      ?>
                    </td>

                    <td><?= $formattedDuration ?></td>
                    <td>
                      <span class="badge 
                        <?= $s['status'] == 'Completed' ? 'badge-success' : 
                            ($s['status'] == 'In Progress' ? 'badge-warning' : 'badge-secondary') ?>">
                        <?= htmlspecialchars($s['status']) ?>
                      </span>
                    </td>
                    <td>
                      <button class="btn btn-info btn-sm"
                              data-toggle="modal"
                              data-target="#viewDetailsModal"
                              data-wor="<?= $s['wor_id'] ?>"
                              data-session="<?= $s['session_id'] ?>">
                        <i class="fa fa-eye"></i> View
                      </button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<!-- 🟢 WORK DURATION SUMMARY MODAL -->
<div class="modal fade" id="summaryModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-xl summary-modal" style="margin-top: 50px !important;">
    <div class="modal-content shadow-sm">
      <div class="modal-header bg-success text-white py-2">
        <h6 class="modal-title"><i class="fa fa-hourglass-half"></i> Work Duration Summary</h6>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body p-3">
        <div class="table-responsive">
          <table id="summaryTable" class="table table-sm table-bordered table-striped mb-0 align-middle">
            <thead class="thead-dark">
              <tr>
                <th>Mechanic</th>
                <th>WOR #</th>
                <th>Tanker</th>
                <th>Duration</th>
                <th>Sessions</th>
                <th>Overall Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($totals as $t): ?>
                <?php
                  $minsTotal = (int)($t['total_duration'] ?? 0);
                  $hours = floor($minsTotal / 60);
                  $mins  = $minsTotal % 60;
                  $status = $t['overall_status'];

                  $badgeClass = match ($status) {
                    'Completed'   => 'badge-success',
                    'In Progress' => 'badge-warning',
                    'On Hold'     => 'badge-secondary',
                    default       => 'badge-light'
                  };
                ?>
                <tr class="text-center">
                  <td><?= htmlspecialchars($t['mechanic_name']) ?></td>
                  <td><?= htmlspecialchars($t['wor_number']) ?></td>
                  <td><?= htmlspecialchars($t['tanker_code']) ?></td>
                  <td><span class="badge badge-duration"><?= "{$hours}h {$mins}m" ?></span></td>
                  <td><?= (int)$t['session_count'] ?></td>
                  <td><span class="badge <?= $badgeClass ?>"><?= htmlspecialchars($status) ?></span></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- 🔍 View Details Modal -->
<div class="modal fade" id="viewDetailsModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title"><i class="fa fa-info-circle"></i> Work Session Details</h5>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="sessionDetails">
        <div class="text-center text-muted py-4">Loading details...</div>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
$(function () {
  $('#workSessionTable').DataTable({
    pageLength: 10,
    responsive: true,
    autoWidth: false,
    order: [[0, 'desc']],
    columnDefs: [
      { targets: 0, visible: false, searchable: false },
      { targets: 3, visible: false, searchable: false }
    ],
    language: { emptyTable: '<i class="fa fa-info-circle"></i> No work sessions available' }
  });

  $('#summaryModal').on('shown.bs.modal', function () {
    if (!$.fn.DataTable.isDataTable('#summaryTable')) {
      $('#summaryTable').DataTable({
        pageLength: 5,
        responsive: true,
        autoWidth: false,
        ordering: true,
        searching: true,
        language: { search: "Search:", emptyTable: '<i class="fa fa-info-circle"></i> No summarized data available' }
      });
    }
  });

  $('#viewDetailsModal').on('show.bs.modal', function (e) {
    const button = $(e.relatedTarget);
    const wor_id = button.data('wor');
    const session_id = button.data('session');

    $('#sessionDetails').html('<div class="text-center text-muted py-4">Loading details...</div>');
    $.get('fetch_workorder_full_view.php', { wor_id, session_id }, function(res){
      $('#sessionDetails').html(res.html || res);
    }, 'json').fail(function(){
      $('#sessionDetails').html('<div class="text-danger text-center py-4">Failed to load details.</div>');
    });
  });
});
</script>
</body>
</html>
