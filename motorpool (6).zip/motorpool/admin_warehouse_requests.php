<?php
error_reporting(0);
ini_set('display_errors', 0);

session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
  header("Location: login.php");
  exit();
}

include "DB_connection.php";

/* 🧩 Fetch requested items */
$stmt = $conn->prepare("
  SELECT 
    ri.id,
    ri.wor_id,
    COALESCE(wo.wor_number, '-') AS wor_number,
    COALESCE(wo.tanker_code, '-') AS tanker_code,
    COALESCE(wo.plate_no, '-') AS plate_no,
    ri.item_description,
    ri.qty,
    ri.unit,
    COALESCE(ri.status, 'Pending') AS status,
    COALESCE(ri.available_qty, 0) AS available_qty,
    COALESCE(ri.remarks, '-') AS remarks,
    ri.date_requested,
    COALESCE(u.full_name, '-') AS mechanic_name
  FROM requested_items ri
  LEFT JOIN users u ON ri.mechanic_id = u.id
  LEFT JOIN work_orders wo ON ri.wor_id = wo.id
  ORDER BY ri.date_requested DESC
");
$stmt->execute();
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Warehouse - Mechanic Requests</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background:#f4f6fa; }
    h4 { font-weight:bold; }
    .card { overflow-x:auto; }
    table th, table td { text-align:center; vertical-align:middle; white-space: nowrap; }
    table thead th { font-weight:600; }
    .badge { font-size:12px; padding:5px 10px; }
  </style>
</head>
<body>
<input type="checkbox" id="checkbox">
<?php include "inc/header.php"; ?>
<div class="body">
<?php include "inc/nav.php"; ?>

<section class="section-1 mt-3">
  <div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4><i class="fa-solid fa-warehouse"></i> Warehouse - Mechanic Requests</h4>
    </div>

    <div class="card p-3 shadow-sm">
      <table id="requestsTable" class="table table-bordered table-striped">
        <thead class="thead-dark">
          <tr>
            <th>#</th>
            <th>Date Requested</th>
            <th>WOR #</th>
            <th>Tanker Code</th>
            <th>Plate No</th>
            <th>Item Description</th>
            <th>Qty</th>
            <th>Unit</th>
            <th>Status</th>
            <th>Mechanic Remarks</th>
            <th>Requested By</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($requests)): ?>
            <?php $i = 1; foreach($requests as $r): ?>
              <?php 
                $status = $r['status'];
                $avail = (int)$r['available_qty'];
                if ($status === 'Available') {
                  $badge = '<span class="badge badge-success">Available</span>';
                } elseif ($status === 'Partially Available') {
                  $badge = '<span class="badge badge-warning text-dark">Partially Available (' . $avail . ')</span>';
                } elseif ($status === 'Not Available') {
                  $badge = '<span class="badge badge-danger">Not Available</span>';
                } else {
                  $badge = '<span class="badge badge-secondary">Pending</span>';
                }
              ?>
              <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars(date('M d, Y h:i A', strtotime($r['date_requested']))) ?></td>
                <td><?= htmlspecialchars($r['wor_number']) ?></td>
                <td><?= htmlspecialchars($r['tanker_code']) ?></td>
                <td><?= htmlspecialchars($r['plate_no']) ?></td>
                <td><?= htmlspecialchars($r['item_description']) ?></td>
                <td><?= htmlspecialchars($r['qty']) ?></td>
                <td><?= htmlspecialchars($r['unit']) ?></td>
                <td><?= $badge ?></td>
                <td><?= nl2br(htmlspecialchars($r['remarks'])) ?></td>
                <td><?= htmlspecialchars($r['mechanic_name']) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr class="no-data">
              <td colspan="11" class="text-center text-muted">
                <i class="fa fa-info-circle"></i> No mechanic item requests found.
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
</div>

<!-- ✅ Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap4.min.js"></script>

<script>
$(document).ready(function() {
  const table = $('#requestsTable');

  // 🔧 Prevent DataTables alert for empty tables
  $.fn.dataTable.ext.errMode = 'none';

  // If no rows, add invisible filler <td>s so DataTables sees 11 cells
  if (table.find('tbody tr.no-data').length) {
    const filler = '<td style="display:none"></td>'.repeat(10);
    table.find('tbody tr.no-data td').after(filler);
  }

  // Initialize safely
  table.DataTable({
    responsive: true,
    deferRender: true,
    pageLength: 10,
    autoWidth: false,
    ordering: true,
    dom: '<"row mb-2"<"col-md-6"l><"col-md-6 text-right"f>>rtip',
    language: {
      search: "Search:",
      emptyTable: "<i class='fa fa-info-circle'></i> No mechanic requests available."
    }
  });
});
</script>
</body>
</html>
