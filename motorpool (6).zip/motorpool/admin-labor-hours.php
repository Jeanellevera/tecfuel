<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}
include __DIR__ . "/DB_connection.php";

/* ----------------------------------------------------------
   🧩 FILTER HANDLING (Custom Range Only)
---------------------------------------------------------- */
$startDate = $_GET['startDate'] ?? null;
$endDate   = $_GET['endDate'] ?? null;

$where = "WHERE ws.work_start IS NOT NULL AND ws.work_end IS NOT NULL";

if (!empty($startDate) && !empty($endDate)) {
  $where .= " AND DATE(ws.work_start) BETWEEN :startDate AND :endDate";
}

/* ----------------------------------------------------------
   🧭 FETCH SUMMARY PER MECHANIC (with break deductions)
---------------------------------------------------------- */
$sql = "
    SELECT 
        u.id AS mechanic_id,
        u.full_name AS mechanic_name,
        IFNULL(SUM(
          GREATEST(
            TIMESTAMPDIFF(MINUTE, ws.work_start, ws.work_end)
            - IF(TIME(ws.work_start) < '10:15:00' AND TIME(ws.work_end) > '10:00:00', 15, 0)
            - IF(TIME(ws.work_start) < '13:00:00' AND TIME(ws.work_end) > '12:00:00', 60, 0)
            - IF(TIME(ws.work_start) < '15:15:00' AND TIME(ws.work_end) > '15:00:00', 15, 0),
            0
          )
        ), 0) AS total_minutes,
        COUNT(ws.session_id) AS total_sessions
    FROM work_sessions ws
    LEFT JOIN users u ON ws.mechanic_id = u.id
    $where
    GROUP BY u.id, u.full_name
    ORDER BY total_minutes DESC
";
$stmt = $conn->prepare($sql);

if (!empty($startDate) && !empty($endDate)) {
  $stmt->bindValue(':startDate', $startDate);
  $stmt->bindValue(':endDate', $endDate);
}

$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_mechanics = count($rows);
$total_minutes_all = array_sum(array_column($rows, 'total_minutes'));
$total_hours = floor($total_minutes_all / 60);
$total_minutes_rem = $total_minutes_all % 60;
$total_sessions = array_sum(array_column($rows, 'total_sessions'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Total Mechanic Labor Hours</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
<style>
/* ✅ Layout */
.section-1 {
  padding: 25px;
  background: #f8f9fa;
  min-height: 90vh;
  position: relative;
  z-index: 2;
}
.title {
  font-weight: 600;
  color: #333;
}

/* ✅ Filter Bar (Right-Aligned) */
#filterForm {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 8px;
}
#filterForm .form-control-sm {
  min-width: 130px;
}
#filterForm button {
  font-weight: 600;
  padding: 4px 10px;
}

/* ✅ Summary Boxes */
.summary-card {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  margin-bottom: 25px;
  gap: 15px;
  position: relative;
  z-index: 1;
}
.summary-box {
  flex: 1;
  min-width: 220px;
  background: #fff;
  border-radius: 10px;
  padding: 20px 15px;
  text-align: center;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  border: 1px solid #e3e3e3;
  transition: 0.3s ease;
}
.summary-box:hover {
  transform: translateY(-3px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
}
.summary-box i {
  font-size: 28px;
  color: #004080;
  margin-bottom: 10px;
}
.summary-box h5 {
  font-size: 15px;
  font-weight: 600;
  color: #444;
  margin: 0;
}

/* ✅ Table */
.table-responsive {
  position: relative;
  z-index: 5;
}
.table th {
  background: #2c3e50;
  color: #fff;
  text-align: center;
  vertical-align: middle;
}
.table td {
  vertical-align: middle;
  text-align: center;
}
.table tbody tr:nth-child(even) {
  background-color: #f9fbfd;
}

/* ✅ Buttons and Badges */
.badge {
  font-size: 14px;
  padding: 6px 12px;
  border-radius: 8px;
  font-weight: 500;
}
.badge-primary {
  background: #007bff;
}
.badge-secondary {
  background: #6c757d;
}
.viewLogsBtn {
  background: #17a2b8;
  border: none;
  color: #fff;
  padding: 6px 12px;
  border-radius: 6px;
  transition: 0.3s;
  cursor: pointer;
  z-index: 10;
  position: relative;
}
.viewLogsBtn:hover {
  background: #138496;
}

/* ✅ Modal Fixes */
.modal {
  z-index: 1055 !important;
}
.modal-backdrop {
  z-index: 1040 !important;
}
.card, .section-1 {
  overflow: visible !important;
}
#logsModal .modal-dialog {
  max-width: 85%;
}
#logsModal .modal-body {
  max-height: 80vh;
  overflow-y: auto;
}
#logsModal table {
  width: 100%;
  table-layout: fixed;
  word-wrap: break-word;
}
#logsModal th, #logsModal td {
  text-align: center;
  vertical-align: middle;
  white-space: nowrap;
}
#logsModal th {
  background: #031f3f;
  color: white;
  font-size: 14px;
}
#logsModal td {
  font-size: 13px;
}
#logsModal .table-responsive {
  overflow-x: hidden !important;
}
.alert-info {
  font-size: 14px;
  background: #e9f5ff;
  border: 1px solid #bde0fe;
  position: relative;
  z-index: 1;
}
</style>
</head>
<body>
<input type="checkbox" id="checkbox">
<?php include "inc/header.php"; ?>
<div class="body">
<?php include "inc/nav.php"; ?>

<section class="section-1">
  <!-- 🔹 Header -->
  <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
    <h4 class="title mb-2 mb-md-0">
      <i class="fa fa-clock text-primary"></i> Total Mechanic Labor Hours
    </h4>
  </div>

  <!-- 🔹 Filter Info -->
  <?php if ($startDate && $endDate): ?>
    <div class="alert alert-info py-2">
      Showing results from <strong><?= htmlspecialchars($startDate) ?></strong>
      to <strong><?= htmlspecialchars($endDate) ?></strong>.
    </div>
  <?php endif; ?>

  <!-- 🔹 Summary Cards -->
  <div class="summary-card">
    <div class="summary-box"><i class="fa fa-users"></i><h5><?= $total_mechanics ?> Mechanics</h5></div>
    <div class="summary-box"><i class="fa fa-hourglass-half"></i><h5><?= sprintf("%02d:%02d", $total_hours, $total_minutes_rem) ?> Total Hours</h5></div>
    <div class="summary-box"><i class="fa fa-wrench"></i><h5><?= $total_sessions ?> Total Sessions</h5></div>
  </div>

  <!-- 🔹 Filter Bar (Right-Aligned) -->
  <div class="d-flex justify-content-end mb-3">
    <form id="filterForm" class="form-inline">
      <input type="date" id="startDate" name="startDate"
        value="<?= htmlspecialchars($startDate ?? '') ?>"
        class="form-control form-control-sm" required>
      <input type="date" id="endDate" name="endDate"
        value="<?= htmlspecialchars($endDate ?? '') ?>"
        class="form-control form-control-sm" required>
      <button type="submit" class="btn btn-primary btn-sm">
        <i class="fa fa-filter"></i>
      </button>
    </form>
  </div>

  <!-- 🔹 Table -->
  <div class="table-responsive">
    <table id="laborTable" class="table table-bordered table-hover">
      <thead>
        <tr>
          <th>Mechanic Name</th>
          <th>Total Hours</th>
          <th>Total Sessions</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($rows): foreach ($rows as $r):
          $h = floor($r['total_minutes'] / 60);
          $m = $r['total_minutes'] % 60; ?>
          <tr>
            <td class="text-left pl-3"><?= htmlspecialchars($r['mechanic_name'] ?: 'Unknown') ?></td>
            <td><span class="badge badge-primary"><?= sprintf("%02d:%02d", $h, $m) ?></span></td>
            <td><span class="badge badge-secondary"><?= $r['total_sessions'] ?></span></td>
            <td>
              <button class="btn btn-sm viewLogsBtn" 
                      data-id="<?= $r['mechanic_id'] ?>" 
                      data-name="<?= htmlspecialchars($r['mechanic_name']) ?>">
                <i class="fa fa-eye"></i> View Logs
              </button>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="4" class="text-muted text-center">No labor records found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
</div>

<!-- 🔹 Modal -->
<div class="modal fade" id="logsModal" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header text-white" style="background-color: #007bff;">
        <h5 class="modal-title"><i class="fa fa-clipboard-list"></i> Mechanic Logs</h5>
        <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <h6 class="font-weight-bold mb-3">
          <span class="text-dark">Mechanic Name:</span>
          <span id="mechanicName" class="text-dark"></span>
        </h6>
        <div id="logsContent" class="mt-2"></div>
      </div>
    </div>
  </div>
</div>

<!-- ✅ JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap4.min.js"></script>

<script>
$(document).ready(function () {
  const $table = $("#laborTable");
  const $thead = $table.find("thead th");
  const $tbodyRows = $table.find("tbody tr");

  // ✅ Only initialize if table has header AND rows
  if ($thead.length > 0 && $tbodyRows.length > 0) {
    const firstRowCols = $tbodyRows.first().find("td").length;
    const headerCols = $thead.length;

    if (firstRowCols === headerCols) {
      $table.DataTable({
        paging: false,
        searching: false,
        info: false,
        ordering: true,
        order: [[0, "asc"]],
        lengthChange: false,
        autoWidth: false,
        responsive: true,
        language: { emptyTable: "No labor records found." },
        dom: '<"table-container"t>'
      });
    } else {
      console.warn("⚠️ DataTables skipped: mismatched columns detected.");
    }
  } else {
    console.warn("⚠️ DataTables skipped: no rows or header found.");
  }

  // ✅ Handle filter form
  $("#filterForm").on("submit", function(e) {
    e.preventDefault();
    const params = $(this).serialize();
    window.location.href = "admin-labor-hours.php?" + params;
  });

  // ✅ “View Logs” Button Function
  $(document).on("click", ".viewLogsBtn", function() {
    const mechanicId = $(this).data("id");
    const mechanicName = $(this).data("name");
    const startDate = $("#startDate").val();
    const endDate = $("#endDate").val();

    $("#mechanicName").text(mechanicName);
    $("#logsContent").html("<div class='text-center py-4 text-muted'><i class='fa fa-spinner fa-spin'></i> Loading logs...</div>");
    $("#logsModal").modal("show");

    // 🔹 Fetch logs via AJAX
    $.ajax({
      url: "fetch_mechanic_logs.php",
      type: "GET",
      data: { id: mechanicId, startDate: startDate, endDate: endDate },
      success: function(response) {
        $("#logsContent").html(response);
      },
      error: function(xhr, status, error) {
        $("#logsContent").html(`<div class='text-danger text-center py-3'>Error loading logs: ${error}</div>`);
      }
    });
  });
});
</script>
</body>
</html>
