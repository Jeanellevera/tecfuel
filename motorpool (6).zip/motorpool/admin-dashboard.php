<?php 
session_start();
if (isset($_SESSION['role']) && isset($_SESSION['id']) && $_SESSION['role'] == "admin") {
    include "DB_connection.php";
    include "app/Model/User.php";


    // ✅ Today's date
    $today = date("Y-m-d");

    // ✅ Depots
    $depots  = ["KITROL","JETTI","PETRO DE ORO"];

    // ✅ Fetch only active Tankers
    $stmt = $conn->prepare("
        SELECT tanker_code 
        FROM vehicles 
        WHERE category = 'Tanker' AND status = 'active' 
        ORDER BY tanker_code ASC
    ");
    $stmt->execute();
    $tankers = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // ✅ Fetch today's available tankers
    $stmt = $conn->prepare("SELECT COUNT(DISTINCT tanker_code) as cnt 
                             FROM tanker_checklist 
                             WHERE checklist_date = ? AND available = 1");
    $stmt->execute([$today]);
    $todayAvailableCount = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .dashboard {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        .dashboard-item {
            flex: 1 1 200px;
            padding: 20px;
            text-align: center;
            border-radius: 10px;
            color: #fff;
            cursor: pointer;
            transition: transform 0.2s ease-in-out;
        }
        .dashboard-item i {
            font-size: 40px;
            margin-bottom: 10px;
            display: block;
        }
        .dashboard-item span {
            font-size: 18px;
            font-weight: bold;
            display: block;
        }
        .dashboard-item:hover {
            transform: scale(1.05);
        }
        .dashboard-item.labor {
            background: #e74c3c;
        }
        .dashboard-item.backjobs {
            background: #3498db;
        }
        .dashboard-item.tanker {
            background: #27ae60;
            position: relative;
        }
        .dashboard-item.tanker .badge {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 0.9rem;
            background: #fff;
            color: #27ae60;
        }
    </style>
</head>
<body>
<input type="checkbox" id="checkbox">
<?php include "inc/header.php" ?>
<div class="body">
    <?php include "inc/nav.php" ?>
    <section class="section-1">
        <h3>Admin Dashboard</h3>
        <div class="dashboard">
            <div class="dashboard-item tanker" data-bs-toggle="modal" data-bs-target="#availabilityModal">
                <i class="fa fa-truck"></i>
                <span>Tanker Availability</span>
                <span class="badge rounded-pill"><?= $todayAvailableCount ?></span>
            </div>
            <div class="dashboard-item labor">
                <i class="fa fa-clock"></i>
                <span>Total Labor Hours</span>
            </div>
            <!--div class="dashboard-item backjobs">
                <i class="fa fa-window-close-o"></i>
                <span>Total Backjobs</span>
            </div-->
        </div>


     <!-- 🔹 PERFORMANCE SECTION BELOW CARDS -->
<div class="container-fluid mt-5">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="text-primary fw-bold">Performance Overview</h4>
    <div class="d-flex gap-2">
      <input type="date" id="startDate" class="form-control form-control-sm">
      <input type="date" id="endDate" class="form-control form-control-sm">
      <button id="filterBtn" class="btn btn-success btn-sm">
        <i class="fa fa-filter"></i> Filter
      </button>
    </div>
  </div>

  <div class="row justify-content-center">
    <!-- 🔵 HOURS PER ACTIVITY -->
    <div class="col-md-4 mb-4">
      <div class="card shadow-sm border-0 h-100">
        <div class="card-body p-3 d-flex flex-column align-items-center justify-content-center">
          <h6 class="text-center mb-3 fw-bold" style="font-size:14px;">HOURS WORKED PER ACTIVITY</h6>
          <canvas id="activityChart" style="max-height:400px;"></canvas>
        </div>
      </div>
    </div>

    <!-- 🟢 HOURS PER MECHANIC -->
    <div class="col-md-4 mb-4">
      <div class="card shadow-sm border-0 h-100">
        <div class="card-body p-3 d-flex flex-column align-items-center justify-content-center">
          <h6 class="text-center mb-3 fw-bold" style="font-size:14px;">HOURS WORKED PER MECHANIC</h6>
          <canvas id="mechanicChart" style="max-height:400px;"></canvas>
        </div>
      </div>
    </div>


    <!-- 🔷 HOURS WORKED PER VEHICLE -->
    <div class="col-md-4 mb-4">
      <div class="card shadow-sm border-0 h-100">
        <div class="card-body p-3" style="padding-top: 35px;"> <!-- balanced vertical alignment -->
          <h6 class="text-center mb-3 fw-bold" style="font-size:14px;">
            HOURS WORKED PER VEHICLE
          </h6>
          <!-- responsive and scrollable bar chart container -->
          <div style="width:100%; overflow-x:auto; overflow-y:hidden; padding-top:10px; position:relative; height:340px;">
            <canvas id="vehicleChart" style="min-width:550px; width:100%; height:100%;"></canvas>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
/* 💰 REPAIR COST PER TANKER */
$sql_costs = "
  SELECT 
      wo.tanker_code AS vehicle_code,
      COALESCE(SUM(wd.total), 0) AS total_cost
  FROM work_orders wo
  LEFT JOIN withdrawals wd 
      ON wo.wor_number = wd.wor_number
  WHERE wo.status = 'Completed'
  GROUP BY wo.tanker_code
  ORDER BY total_cost DESC
";
$stmt = $conn->prepare($sql_costs);
$stmt->execute();
$repair_costs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- 🟦 REPAIR COSTS PER TANKER (Horizontal Bar) -->
<div class="col-md-12 mt-4">
  <div class="card p-3 shadow-sm">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <h6 class="fw-bold mb-0">REPAIR COSTS PER VEHICLE (₱)</h6>
      <form id="repairFilterForm" class="d-flex align-items-center gap-2">
        <label class="me-1 text-muted" style="font-size:13px;">From:</label>
        <input type="date" id="repairStart" class="form-control form-control-sm">
        <label class="me-1 text-muted" style="font-size:13px;">To:</label>
        <input type="date" id="repairEnd" class="form-control form-control-sm">
        <button type="submit" class="btn btn-success btn-sm"><i class="fa fa-filter"></i></button>
      </form>
    </div>

    <div style="width:100%; height:250px; overflow-x:auto;">
      <canvas id="repairCostChart" style="min-width:500px; width:100%; height:220px;"></canvas>
    </div>
  </div>
</div>

<!-- 🚛 Tanker Availability Modal -->
<div class="modal fade" id="availabilityModal" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-centered" style="max-width: 1000px;"> <!-- ✅ wider modal -->
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title">Tanker Availability - <?= date("M d, Y (D)") ?></h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <div class="table-responsive" style="overflow-x: visible !important;"> <!-- ✅ no scroll -->
          <table class="table table-bordered text-center align-middle mb-0" style="width: 100%; table-layout: fixed;">
            <colgroup>
              <col style="width: 100px;"> <!-- Tanker -->
              <col style="width: 120px;"> <!-- KITROL -->
              <col style="width: 120px;"> <!-- JETTI -->
              <col style="width: 130px;"> <!-- PETRO DE ORO -->
            </colgroup>

            <thead class="table-dark">
              <tr>
                <th>Tanker</th>
                <?php foreach ($depots as $depot): ?>
                  <th><?= htmlspecialchars($depot) ?></th>
                <?php endforeach; ?>
              </tr>
            </thead>

            <tbody>
              <?php foreach ($tankers as $tanker): ?>
                <tr>
                  <td><b><?= htmlspecialchars($tanker) ?></b></td>
                  <?php foreach ($depots as $depot): ?>
                    <td>
                      <?php
                        $stmt = $conn->prepare("
                          SELECT available
                          FROM tanker_checklist
                          WHERE tanker_code = ?
                            AND depot = ?
                            AND checklist_date = ?
                        ");
                        $stmt->execute([$tanker, $depot, $today]);
                        $row = $stmt->fetch(PDO::FETCH_ASSOC);
                      ?>
                      <?php if ($row && $row['available'] == 1): ?>
                        <span class="badge bg-success">Available</span>
                      <?php else: ?>
                        -
                      <?php endif; ?>
                    </td>
                  <?php endforeach; ?>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
</div>


<!-- ✅ Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// ✅ Initialize Bootstrap tooltips
document.addEventListener('DOMContentLoaded', function () {
  const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  tooltipTriggerList.forEach(function (tooltipTriggerEl) {
    new bootstrap.Tooltip(tooltipTriggerEl)
  })
});

Chart.defaults.font.size = 12;
Chart.defaults.font.family = 'Inter, Arial, sans-serif';
const placeholderColor = '#e3e8ee';

// 🔹 Gradient generator for 3D depth
function createGradient(ctx, color) {
  const gradient = ctx.createLinearGradient(0, 0, 0, 300);
  gradient.addColorStop(0, color);
  gradient.addColorStop(1, shadeColor(color, -20));
  return gradient;
}

// 🔹 Helper to darken color for depth
function shadeColor(color, percent) {
  let R = parseInt(color.substring(1,3),16);
  let G = parseInt(color.substring(3,5),16);
  let B = parseInt(color.substring(5,7),16);
  R = parseInt(R*(100+percent)/100);
  G = parseInt(G*(100+percent)/100);
  B = parseInt(B*(100+percent)/100);
  R = (R<255)?R:255; G = (G<255)?G:255; B = (B<255)?B:255;
  const RR = (R.toString(16).length==1)?"0"+R.toString(16):R.toString(16);
  const GG = (G.toString(16).length==1)?"0"+G.toString(16):G.toString(16);
  const BB = (B.toString(16).length==1)?"0"+B.toString(16):B.toString(16);
  return "#"+RR+GG+BB;
}

/* 🧩 Helper: Show No Data Placeholder */
function showNoDataMessage(containerId, message = "No data available") {
  const canvas = document.getElementById(containerId);
  canvas.style.display = "none";
  let msg = document.createElement("div");
  msg.textContent = message;
  msg.style.textAlign = "center";
  msg.style.color = "#888";
  msg.style.fontStyle = "italic";
  msg.style.fontSize = "14px";
  msg.style.padding = "60px 0";
  canvas.parentNode.appendChild(msg);
}

/* 🟢 Load Charts */
function loadCharts(start = '', end = '') {
  fetch('fetch_dashboard_performance.php?start=' + start + '&end=' + end)
    .then(res => res.json())
    .then(data => {
      if (window.activityChartObj) window.activityChartObj.destroy();
      if (window.mechanicChartObj) window.mechanicChartObj.destroy();
      if (window.vehicleChartObj) window.vehicleChartObj.destroy();

      const actCanvas = document.getElementById('activityChart');
      const mechCanvas = document.getElementById('mechanicChart');
      const vehCanvas = document.getElementById('vehicleChart');
      const actCtx = actCanvas.getContext('2d');
      const mechCtx = mechCanvas.getContext('2d');
      const vehCtx = vehCanvas.getContext('2d');
      const palette = ['#007bff','#28a745','#ffc107','#17a2b8','#dc3545','#6f42c1','#20c997','#fd7e14'];

      /* ---------------------------
         🟣 HOURS WORKED PER ACTIVITY
      ---------------------------- */
      const hasAct = data.activities && data.activities.length > 0 && data.activity_hours.some(v => v > 0);
      if (!hasAct) {
        actCanvas.style.display = "none";
        showNoDataMessage('activityChart', "No data available");
      } else {
        window.activityChartObj = new Chart(actCtx, {
          type: 'pie',
          data: {
            labels: data.activities,
            datasets: [{
              data: data.activity_hours,
              backgroundColor: palette.map(c => createGradient(actCtx, c)),
              borderWidth: 0,
              hoverOffset: 15
            }]
          },
          options: {
            responsive: true,
            animation: { animateRotate: true, duration: 1000, easing: 'easeOutElastic' },
            plugins: {
              legend: { position: 'bottom', labels: { color: '#444' } },
              tooltip: {
                backgroundColor: 'rgba(0,0,0,0.75)',
                titleFont: { weight: 'bold' },
                bodyFont: { size: 12 },
                callbacks: {
                  label: ctx => {
                    if (!ctx.parsed) return '';
                    const value = ctx.parsed;
                    const unit = value === 1 ? 'hr' : 'hrs';
                    const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
                    const percent = ((value / total) * 100).toFixed(1);
                    return `${ctx.label}: ${value} ${unit} (${percent}%)`;
                  }
                }
              }
            }
          }
        });
      }

      /* ---------------------------
         🟢 HOURS WORKED PER MECHANIC
      ---------------------------- */
      const hasMech = data.mechanics && data.mechanics.length > 0 && data.mechanic_hours.some(v => v > 0);
      if (!hasMech) {
        mechCanvas.style.display = "none";
        showNoDataMessage('mechanicChart', "No data available");
      } else {
        window.mechanicChartObj = new Chart(mechCtx, {
          type: 'doughnut',
          data: {
            labels: data.mechanics,
            datasets: [{
              data: data.mechanic_hours,
              backgroundColor: palette.map(c => createGradient(mechCtx, c)),
              borderWidth: 0,
              hoverOffset: 15
            }]
          },
          options: {
            cutout: '60%',
            responsive: true,
            animation: { animateRotate: true, duration: 1000, easing: 'easeOutElastic' },
            plugins: {
              legend: { position: 'bottom', labels: { color: '#444' } },
              tooltip: {
                backgroundColor: 'rgba(0,0,0,0.75)',
                bodyFont: { size: 12 },
                callbacks: {
                  label: ctx => {
                    if (!ctx.parsed) return '';
                    const value = ctx.parsed;
                    const unit = value === 1 ? 'hr' : 'hrs';
                    const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
                    const percent = ((value / total) * 100).toFixed(1);
                    return `${ctx.label}: ${value} ${unit} (${percent}%)`;
                  }
                }
              }
            }
          }
        });
      }

      /* ---------------------------
         🔵 HOURS WORKED PER VEHICLE
      ---------------------------- */
      const hasVeh = data.vehicles && data.vehicles.length > 0 && data.vehicle_hours.some(v => v > 0);
      if (!hasVeh) {
        vehCanvas.style.display = "none";
        showNoDataMessage('vehicleChart', "No data available");
      } else {
        window.vehicleChartObj = new Chart(vehCtx, {
          type: 'bar',
          data: {
            labels: data.vehicles,
            datasets: [{
              label: 'Hours',
              data: data.vehicle_hours,
              backgroundColor: createGradient(vehCtx, '#007bff'),
              borderRadius: 10,
              barThickness: 40
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 1200, easing: 'easeOutBounce' },
            scales: {
              y: {
                beginAtZero: true,
                grid: { color: '#f0f0f0' },
                ticks: { stepSize: 1, color: '#555' },
                display: true
              },
              x: {
                grid: { display: false },
                ticks: { color: '#555', font: { size: 11 } }
              }
            },
            plugins: {
              legend: { display: false },
              tooltip: {
                backgroundColor: 'rgba(0,0,0,0.75)',
                bodyFont: { size: 12 },
                callbacks: {
                  label: ctx => {
                    if (!ctx.parsed.y) return '';
                    const value = ctx.parsed.y;
                    const unit = value === 1 ? 'hr' : 'hrs';
                    return `${ctx.label}: ${value} ${unit}`;
                  }
                }
              }
            }
          }
        });
      }
    });
}

// 🔹 Load initial charts
loadCharts();

// Filter
document.getElementById('filterBtn').addEventListener('click', () => {
  const start = document.getElementById('startDate').value;
  const end = document.getElementById('endDate').value;
  loadCharts(start, end);
});
</script>

<script>
$(document).ready(function() {

  // ✅ Click to load Labor Hours section
  $(".labor").on("click", function() {
    window.location.href = "admin-labor-hours.php";
  });

  // ✅ Click to load Backjobs section
  $(".backjobs").on("click", function() {
    window.location.href = "admin-backjobs.php";
  });

});
</script>
<script>
// 🧮 REPAIR COSTS PER TANKER (Show All + Filter)
let repairChart = null;

function loadRepairCostChart(start = '', end = '') {
  const url = (start && end)
    ? `fetch_repair_costs.php?start=${start}&end=${end}`
    : `fetch_repair_costs.php`;

  fetch(url)
    .then(res => res.json())
    .then(data => {
      const ctx = document.getElementById('repairCostChart').getContext('2d');
      if (repairChart) repairChart.destroy();

      if (data.length === 0) {
        ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
        ctx.font = "14px Arial";
        ctx.fillStyle = "#999";
        ctx.textAlign = "center";
        ctx.fillText("No repair cost data available", ctx.canvas.width / 2, ctx.canvas.height / 2);
        return;
      }

      const labels = data.map(d => d.vehicle_code);
      const values = data.map(d => parseFloat(d.total_cost));

      repairChart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [{
            label: 'Total Repair Cost (₱)',
            data: values,
            backgroundColor: '#007bff',
            borderRadius: 6
          }]
        },
        options: {
          indexAxis: 'y',
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              beginAtZero: true,
              ticks: {
                callback: value => '₱ ' + value.toLocaleString(),
                color: '#555'
              },
              title: {
                display: true,
                text: 'Total Repair Cost (₱)',
                font: { weight: 'bold' }
              }
            },
            y: {
              ticks: { color: '#555' },
              title: {
                display: true,
                text: 'Tanker',
                font: { weight: 'bold' }
              }
            }
          },
          plugins: {
            legend: { display: false },
            tooltip: {
              callbacks: {
                label: ctx => '₱ ' + Number(ctx.parsed.x).toLocaleString()
              }
            }
          }
        }
      });
    });
}

document.addEventListener('DOMContentLoaded', function() {
  const startInput = document.getElementById('repairStart');
  const endInput = document.getElementById('repairEnd');

  // ✅ Load all data by default
  loadRepairCostChart();

  // ✅ Filter manually when user clicks Filter
  document.getElementById('repairFilterForm').addEventListener('submit', function(e) {
    e.preventDefault();
    if (!startInput.value || !endInput.value) {
      alert("Please select both start and end dates.");
      return;
    }
    loadRepairCostChart(startInput.value, endInput.value);
  });
});
</script>
</body>
</html>
<?php 
} else { 
   header("Location: login.php?error=Unauthorized Access");
   exit();
}
?>
