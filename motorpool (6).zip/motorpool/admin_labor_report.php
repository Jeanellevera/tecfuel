<?php
include "DB_connection.php";

/* 🧮 Break overlap deduction function */
function deductBreaks($start, $end) {
    if (empty($start) || empty($end)) return 0;
    $start = new DateTime($start);
    $end   = new DateTime($end);
    if ($end <= $start) return 0;

    $total = (int) round(($end->getTimestamp() - $start->getTimestamp()) / 60);
    $date = $start->format('Y-m-d');
    $breaks = [
        [$date . ' 10:00:00', $date . ' 10:15:00'],
        [$date . ' 12:00:00', $date . ' 13:00:00'],
        [$date . ' 15:00:00', $date . ' 15:15:00']
    ];

    $deduct = 0;
    foreach ($breaks as [$bStart, $bEnd]) {
        $bs = new DateTime($bStart);
        $be = new DateTime($bEnd);
        $overlapStart = max($start->getTimestamp(), $bs->getTimestamp());
        $overlapEnd   = min($end->getTimestamp(), $be->getTimestamp());
        if ($overlapEnd > $overlapStart) {
            $deduct += (int) round(($overlapEnd - $overlapStart) / 60);
        }
    }

    return max(0, $total - $deduct);
}

/* 🗓 Default Date Range (This Week) */
$start = isset($_GET['from']) ? $_GET['from'] : date('Y-m-d', strtotime('monday this week'));
$end   = isset($_GET['to'])   ? $_GET['to']   : date('Y-m-d', strtotime('saturday this week'));

/* 🧾 Fetch only latest session per WOR */
$stmt = $conn->prepare("
  SELECT 
      ws.session_id,
      ws.wor_id,
      ws.activity,
      ws.work_start,
      ws.work_end,
      ws.updated_at,
      u.full_name AS mechanic_name,
      wo.wor_number,
      wo.tanker_code,
      wo.status
  FROM work_sessions ws
  INNER JOIN (
      SELECT wor_id, MAX(session_id) AS latest_session
      FROM work_sessions
      GROUP BY wor_id
  ) latest ON ws.wor_id = latest.wor_id AND ws.session_id = latest.latest_session
  LEFT JOIN users u ON ws.mechanic_id = u.id
  LEFT JOIN work_orders wo ON ws.wor_id = wo.id
  WHERE DATE(ws.work_start) BETWEEN ? AND ?
  ORDER BY ws.work_start DESC
");
$stmt->execute([$start, $end]);
$sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* 📊 Apply deductions & summaries */
foreach ($sessions as &$s) {
    $s['total_minutes'] = deductBreaks($s['work_start'], $s['work_end']);
}
unset($s);

$totalMinutes = array_sum(array_column($sessions, 'total_minutes'));
$totalHours = round($totalMinutes / 60, 2);
$mechanics = array_unique(array_column($sessions, 'mechanic_name'));
$totalMechanics = count($mechanics);
$avgHours = $totalMechanics > 0 ? round($totalHours / $totalMechanics, 2) : 0;
?>

<style>
.report-card { background: #fff; border-radius: 6px; padding: 15px 20px; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08); margin-bottom: 15px; }
.summary-bar { text-align: left; margin-bottom: 10px; }
.summary-bar h6 { font-weight: 700; color: #198754; font-size: 15px; margin-bottom: 6px; }
.summary-bar .btn { font-size: 13px; padding: 4px 8px; font-weight: 600; }
.date-filter { display: flex; align-items: center; gap: 6px; justify-content: flex-end; margin-bottom: 8px; }
.date-filter label { font-weight: 600; font-size: 13px; margin-bottom: 0; }
.date-filter input { width: 140px; font-size: 13px; padding: 3px 5px; }
.table { font-size: 13px; margin-bottom: 0; border-collapse: collapse; }
.table td, .table th { text-align: center !important; vertical-align: middle !important; padding: 6px 10px !important; }
.table thead th {
  background-color: #198754 !important; color: #fff !important; font-weight: 700 !important;
  font-size: 13.5px !important; letter-spacing: 0.3px; padding: 8px 10px !important; border-bottom: 2px solid #157347;
}
.dt-buttons .btn { background: #fff !important; border: 1px solid #ccc !important; color: #333 !important;
  font-size: 13px; padding: 4px 8px; margin-right: 4px; border-radius: 4px; transition: 0.2s ease-in-out; }
.dt-buttons .btn:hover { background: #f8f9fa !important; border-color: #999 !important; }
.dataTables_wrapper .dataTables_filter { display: flex; align-items: center; gap: 8px; }
.dataTables_wrapper .dataTables_filter input { height: 28px; font-size: 13px; }
.dataTables_wrapper .dataTables_info { font-size: 12px; color: #555; }
</style>

<div class="report-card">
  <div class="date-filter">
    <label>Start:</label>
    <input type="date" id="fromLabor" value="<?= $start ?>" class="form-control form-control-sm">
    <label>End:</label>
    <input type="date" id="toLabor" value="<?= $end ?>" class="form-control form-control-sm">
    <button id="filterLabor" class="btn btn-success btn-sm"><i class="fa fa-filter"></i></button>
  </div>

  <div class="summary-bar mb-2">
    <h6><i class="fa fa-briefcase me-1"></i> Labor Hours Report</h6>
    <div class="d-flex flex-wrap gap-2">
      <button class="btn btn-outline-primary btn-sm d-flex align-items-center">
        <i class="fa fa-clock me-1"></i>
        <span>Total Hours:</span>&nbsp;<b><?= $totalHours ?></b>
      </button>
      <button class="btn btn-outline-success btn-sm d-flex align-items-center">
        <i class="fa fa-users me-1"></i>
        <span>Mechanics:</span>&nbsp;<b><?= $totalMechanics ?></b>
      </button>
      <button class="btn btn-outline-info btn-sm d-flex align-items-center">
        <i class="fa fa-chart-line me-1"></i>
        <span>Avg per Mechanic:</span>&nbsp;<b><?= $avgHours ?></b>
      </button>
    </div>
  </div>

  <div class="table-responsive">
    <table id="laborTable" class="table table-bordered table-striped table-sm text-center">
      <thead>
        <tr>
          <th>Date & Time</th>
          <th>Mechanic</th>
          <th>WOR #</th>
          <th>Tanker</th>
          <th>Activity</th>
          <th>Start Time</th>
          <th>End Time</th>
          <th>Time Spent</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($sessions as $s): ?>
        <tr>
          <td>
            <?php 
              if (!empty($s['updated_at'])) {
                echo date('Y-m-d H:i', strtotime($s['updated_at']));
              } else {
                echo date('Y-m-d H:i', strtotime($s['work_start']));
              }
            ?>
          </td>
          <td><?= htmlspecialchars($s['mechanic_name']) ?></td>
          <td><?= htmlspecialchars($s['wor_number']) ?></td>
          <td><?= htmlspecialchars($s['tanker_code']) ?></td>
          <td><?= htmlspecialchars($s['activity']) ?></td>
          <td><?= date('H:i', strtotime($s['work_start'])) ?></td>
          <td><?= !empty($s['work_end']) ? date('H:i', strtotime($s['work_end'])) : '-' ?></td>
          <td>
            <?php
              $mins = $s['total_minutes'];
              $hours = floor($mins / 60);
              $minutes = $mins % 60;
              echo sprintf("%02dh %02dm", $hours, $minutes);
            ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
$(document).ready(function() {
  if ($.fn.DataTable.isDataTable('#laborTable')) $('#laborTable').DataTable().destroy();

  $('#laborTable').DataTable({
    pageLength: 25,
    order: [[0, 'desc']],
    dom: '<"d-flex justify-content-between align-items-center mb-2"Bf>rtip',
    buttons: [
      { extend: 'excelHtml5', title: 'TEC Fuel & Energy Solutions Inc. - Labor Hours Report', className: 'btn btn-light btn-sm', text: '<i class="fa fa-file-excel-o"></i> Excel' },
      { extend: 'pdfHtml5', title: 'TEC Fuel & Energy Solutions Inc. - Labor Hours Report', orientation: 'landscape', pageSize: 'A4', className: 'btn btn-light btn-sm', text: '<i class="fa fa-file-pdf-o"></i> PDF',
        customize: function (doc) {
          doc.content.push({ text: '© 2025 JJJ Creations @ TEC Fuel & Energy Solutions Inc. All Rights Reserved.', style: 'footer', alignment: 'center', margin: [0, 10, 0, 0] });
          doc.styles.footer = { fontSize: 9, italics: true, color: '#555' };
        }
      },
      { extend: 'print', title: '<h3>TEC Fuel & Energy Solutions Inc.<br>Labor Hours Report</h3>', className: 'btn btn-light btn-sm', text: '<i class="fa fa-print"></i> Print',
        customize: function (win) {
          $(win.document.body).find('h3').css({'text-align':'center','font-size':'18px','margin-bottom':'10px','font-weight':'bold'});
          $(win.document.body).append(`<div style="text-align:center; margin-top:30px; font-size:10px; color:#555;">© 2025 JJJ Creations @ TEC Fuel & Energy Solutions Inc. All Rights Reserved.</div>`);
          $(win.document.body).find('table').addClass('compact').css({'font-size':'12px','width':'100%','border-collapse':'collapse'});
          $(win.document.body).find('table, th, td').css({'border':'1px solid #555','padding':'4px'});
        }
      }
    ],
    language: { search: "Search:" },
    initComplete: function() {
      $('#laborTable_wrapper').append(`<div class="text-center mt-3 text-muted small">© 2025 JJJ Creations @ TEC Fuel & Energy Solutions Inc. All Rights Reserved.</div>`);
    }
  });

  $('#filterLabor').on('click', function() {
    const from = $('#fromLabor').val();
    const to = $('#toLabor').val();
    $('#reportContainer').load('admin_labor_report.php?from=' + from + '&to=' + to);
  });
});
</script>
