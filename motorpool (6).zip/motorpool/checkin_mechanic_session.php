<?php
session_start();
include "DB_connection.php";
header('Content-Type: application/json');

$mechanic_id = $_SESSION['id'] ?? null;
if (!$mechanic_id) {
  echo json_encode(["success" => false, "message" => "Unauthorized"]);
  exit;
}

$wor_id = $_POST['wor_id'] ?? null;
if (!$wor_id) {
  echo json_encode(["success" => false, "message" => "Missing WOR ID"]);
  exit;
}

/* -------------------------------------------------
   🔍 1️⃣ Check if an existing session exists
-------------------------------------------------- */
$stmt = $conn->prepare("
  SELECT session_id, work_start, work_end, status
  FROM work_sessions
  WHERE wor_id = ? AND mechanic_id = ?
  ORDER BY session_id DESC LIMIT 1
");
$stmt->execute([$wor_id, $mechanic_id]);
$existing = $stmt->fetch(PDO::FETCH_ASSOC);

if ($existing) {
  echo json_encode([
    "success" => true,
    "message" => "Existing session loaded",
    "start_time" => $existing['work_start'],
    "end_time"   => $existing['work_end'],
    "status"     => $existing['status']
  ]);
  exit;
}

/* -------------------------------------------------
   ✅ 2️⃣ Do NOT auto-create session or force Pending
   → Just return “no session yet” to let mechanic decide.
-------------------------------------------------- */
echo json_encode([
  "success" => true,
  "message" => "No existing session — mechanic can start manually",
  "start_time" => null,
  "end_time"   => null,
  "status"     => "Pending"
]);
?>
