<?php

namespace App\Controllers;
use App\Models\WorkorderModel;
use App\Models\TankerModel;
use App\Models\DriverModel;

class Workorders extends BaseController
{
    public function create()
    {
        $tankerModel = new TankerModel();
        $driverModel = new DriverModel();

        $data['drivers'] = $driverModel->findAll();
        $data['tankers'] = $tankerModel->findAll();

        // Generate auto WOR number
        $workorderModel = new WorkorderModel();
        $last = $workorderModel->orderBy('id', 'DESC')->first();
        $nextId = $last ? $last['id'] + 1 : 1;
        $data['wor_no'] = "WN-" . str_pad($nextId, 5, "0", STR_PAD_LEFT);

        return view('workorder_form', $data);
    }

    public function store()
    {
        $workorderModel = new WorkorderModel();

        $workorderModel->save([
            'wor_no'      => $this->request->getPost('wor_no'),
            'driver'      => $this->request->getPost('driver'),
            'tanker_code' => $this->request->getPost('tanker_code'),
            'plate_no'    => $this->request->getPost('plate_no'),
            'odo'         => $this->request->getPost('odo'),
            'symptoms'    => $this->request->getPost('symptoms')
        ]);

        return redirect()->to('/workorders/create')->with('success', 'Work Order saved successfully!');
    }

    // API for auto-fill plate number
    public function getPlate($tankerCode)
    {
        $tankerModel = new TankerModel();
        $tanker = $tankerModel->where('tanker_code', $tankerCode)->first();
        return $this->response->setJSON($tanker);
    }
}
