<?php namespace App\Controllers;

use App\Models\WorkOrderModel;

class Dashboard extends BaseController
{
    public function index()
{
    $model = new \App\Models\WorkOrderModel();

    $workorders  = $model->orderBy('id', 'DESC')->findAll();
    $totalOrders = $model->countAllResults();

    return view('dashboard', [
        'workorders'  => $workorders,   // match with view
        'totalOrders' => $totalOrders
    ]);
}


    public function addWorkOrder()
    {
        helper(['form']);
        echo view('driver_form');
    }

    public function saveWorkOrder()
    {
        $model = new WorkOrderModel();

        $data = [
            'wor_no'      => $this->request->getVar('wor_no'),
            'driver'      => $this->request->getVar('driver'),
            'tanker_code' => $this->request->getVar('tanker_code'),
            'plate_no'    => $this->request->getVar('plate_no'),
            'odo'         => $this->request->getVar('odo'),
            'symptoms'    => $this->request->getVar('symptoms'),
            'status'      => 'Pending',
        ];

        $model->save($data);

        return redirect()->to('/dashboard');
    }
}
