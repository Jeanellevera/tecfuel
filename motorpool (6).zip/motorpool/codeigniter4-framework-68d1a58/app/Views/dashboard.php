<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Driver Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .sidebar { background: #1d4ed8; min-height: 100vh; color: white; }
    .status-high { background: red; color: white; padding: 3px 8px; border-radius: 4px; }
    .status-medium { background: orange; color: black; padding: 3px 8px; border-radius: 4px; }
    .status-low { background: green; color: white; padding: 3px 8px; border-radius: 4px; }
  </style>
</head>
<body class="d-flex">

  <!-- Sidebar -->
  <div class="sidebar p-3">
    <h5>MENU</h5>
    <a href="#" class="btn btn-light w-100 mb-2">Dashboard</a>
    <a href="#" class="btn btn-light w-100">Work Order</a>
  </div>

  <!-- Main Content -->
  <div class="flex-grow-1 p-4">
    <div class="d-flex justify-content-between mb-3">
      <h3>WELCOME BACK DRIVER!</h3>
      <input type="text" id="search" class="form-control w-25" placeholder="Search...">
    </div>

    <div class="row">
      <!-- Table -->
      <div class="col-md-9">
        <table class="table table-bordered table-striped" id="workorderTable">
          <thead class="table-primary">
            <tr>
              <th>Date</th>
              <th>WOR #</th>
              <th>Driver</th>
              <th>Tanker</th>
              <th>Plate #</th>
              <th>ODO</th>
              <th>Symptoms/Trouble</th>
            </tr>
          </thead>
          <tbody>
    <?php if (!empty($workorders) && is_array($workorders)): ?>
        <?php foreach ($workorders as $wo): ?>
            <tr>
                <td><?= esc($wo['date']) ?></td>
                <td><?= esc($wo['wor_no']) ?></td>
                <td><?= esc($wo['driver']) ?></td>
                <td><?= esc($wo['tanker_code']) ?></td>
                <td><?= esc($wo['plate_no']) ?></td>
                <td><?= esc($wo['odo']) ?></td>
                <td><?= esc($wo['symptoms']) ?></td>
                <td><?= esc($wo['status']) ?></td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="8" class="text-center">No work orders found</td>
        </tr>
    <?php endif; ?>
</tbody>

        </table>
      </div>

      <!-- Sidebar Right -->
      <div class="col-md-3">
        <div class="bg-primary text-white p-3 rounded">
          <h5 class="text-center">AUGUST</h5>
          <div class="text-center">
            <p>Total Work Orders</p>
            <h2><?= count($workorders) ?></h2>
          </div>
          <hr>
          <p>WOR# STATUS</p>
          <?php foreach($workorders as $wo): ?>
            <div class="d-flex justify-content-between bg-light text-dark p-2 mb-2 rounded">
              <span><?= $wo['wor'] ?></span>
              <span class="status-<?= strtolower($wo['status']) ?>"><?= $wo['status'] ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

<script>
  // Search filter
  document.getElementById("search").addEventListener("keyup", function() {
    let filter = this.value.toLowerCase();
    let rows = document.querySelectorAll("#workorderTable tbody tr");
    rows.forEach(row => {
      row.style.display = row.innerText.toLowerCase().includes(filter) ? "" : "none";
    });
  });
</script>

</body>
</html>
