<!DOCTYPE html>
<html>
<head>
    <title>Driver Work Order Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="p-4 bg-light">

<div class="container bg-white p-4 rounded shadow">
    <h3 class="mb-4">Driver Work Order Form</h3>

    <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <form method="post" action="/workorders/store">
        <!-- Date & Time -->
        <div class="mb-3">
            <label class="form-label">Date & Time</label>
            <input type="text" name="created_at" value="<?= date('Y-m-d H:i:s') ?>" class="form-control" readonly>
        </div>

        <!-- WOR No -->
        <div class="mb-3">
            <label class="form-label">WOR No.</label>
            <input type="text" name="wor_no" value="<?= $wor_no ?>" class="form-control" readonly>
        </div>

        <!-- Driver -->
        <div class="mb-3">
            <label class="form-label">Driver</label>
            <select name="driver" class="form-control" required>
                <option value="">-- Select Driver --</option>
                <?php foreach($drivers as $d): ?>
                    <option value="<?= $d['driver_name'] ?>"><?= $d['driver_name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Tanker Code -->
        <div class="mb-3">
            <label class="form-label">Tanker Code</label>
            <select name="tanker_code" id="tanker_code" class="form-control" required>
                <option value="">-- Select Tanker --</option>
                <?php foreach($tankers as $t): ?>
                    <option value="<?= $t['tanker_code'] ?>"><?= $t['tanker_code'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Plate No -->
        <div class="mb-3">
            <label class="form-label">Plate No.</label>
            <input type="text" name="plate_no" id="plate_no" class="form-control" readonly>
        </div>

        <!-- ODO -->
        <div class="mb-3">
            <label class="form-label">ODO</label>
            <input type="text" name="odo" class="form-control">
        </div>

        <!-- Symptoms -->
        <div class="mb-3">
            <label class="form-label">Symptoms / Trouble</label>
            <textarea name="symptoms" class="form-control"></textarea>
        </div>

        <div class="d-flex justify-content-between">
            <button type="reset" class="btn btn-danger">Clear</button>
            <button type="submit" class="btn btn-success">Save</button>
        </div>
    </form>
</div>

<script>
    // Auto-fill plate number
    $('#tanker_code').on('change', function() {
        let tankerCode = $(this).val();
        if(tankerCode) {
            $.getJSON('/workorders/getPlate/' + tankerCode, function(data) {
                $('#plate_no').val(data.plate_no);
            });
        } else {
            $('#plate_no').val('');
        }
    });
</script>

</body>
</html>
