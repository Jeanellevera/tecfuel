<!DOCTYPE html>
<html>
<head>
    <title>Driver Login</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css'); ?>">
</head>
<body>
    <div class="wrapper">
        <div class="login-box">
            <img src="<?= base_url('images/logo.png'); ?>" alt="logo">
            <h1>DRIVER</h1>
            <?php if(session()->getFlashdata('msg')):?>
                <p style="color:red;"><?= session()->getFlashdata('msg') ?></p>
            <?php endif;?>
            <form action="<?= base_url('/auth') ?>" method="post">
                <div class="input-box">
                    <input type="text" name="email" placeholder="Email" required>
                    <i class='bx bxs-user'></i>
                </div>
                <div class="input-box">
                    <input type="password" name="password" placeholder="Password" required>
                    <i class='bx bxs-lock-alt'></i>
                </div>
                <button type="submit" class="btn">Login</button>
            </form>
        </div>
    </div>
</body>
</html>
