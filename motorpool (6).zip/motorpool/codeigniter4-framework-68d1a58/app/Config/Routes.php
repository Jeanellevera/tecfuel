<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Default route → login form
$routes->get('/', 'Auth::index');

// Auth routes
$routes->get('auth', 'Auth::index');       // for showing login page
$routes->post('auth', 'Auth::login');      // for processing login form
$routes->get('/logout', 'Auth::logout'); // logout (optional)

// Dashboard routes
$routes->get('/dashboard', 'Dashboard::index');
$routes->get('/dashboard/addWorkOrder', 'Dashboard::addWorkOrder');
$routes->post('/dashboard/saveWorkOrder', 'Dashboard::saveWorkOrder');
$routes->get('dashboard', 'Dashboard::index', ['filter' => 'authGuard']);
$routes->get('/', 'Auth::index');           // login page
$routes->post('/login', 'Auth::login');     // login submit
$routes->get('/dashboard', 'Dashboard::index'); // dashboard
$routes->get('/logout', 'Auth::logout');    // logout
$routes->get('/workorders/create', 'Workorders::create');
$routes->post('/workorders/save', 'Workorders::save');
$routes->get('/workorders/getPlate/(:num)', 'Workorders::getPlate/$1');
