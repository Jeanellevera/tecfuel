<?php

namespace App\Models;

use CodeIgniter\Model;

class WorkOrderModel extends Model
{
   protected $table = 'workorders';   // ✅ must match your DB table name
protected $allowedFields = ['wor_no', 'driver', 'tanker_code', 'plate_no', 'odo', 'symptoms', 'status'];
protected $useTimestamps = true;   // if you use created_at

}
