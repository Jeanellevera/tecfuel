<?php
namespace App\Models;
use CodeIgniter\Model;

class TankerModel extends Model
{
    protected $table = 'tankers';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanker_code', 'plate_no'];
}
