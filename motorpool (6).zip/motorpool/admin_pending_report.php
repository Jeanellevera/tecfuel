<?php
include "DB_connection.php";

/* 🗓 Date Range (default = this month) */
$start = $_GET['start_date'] ?? date('Y-m-01');
$end   = $_GET['end_date']   ?? date('Y-m-d');

/* 🧾 Fetch All Work Orders (not just pending) */
$stmt = $conn->prepare("
  SELECT 
      wo.wor_number,
      wo.driver_name,
      wo.tanker_code,
      wo.plate_no,
      COALESCE(
        (SELECT ws2.status 
         FROM work_sessions ws2 
         WHERE ws2.wor_id = wo.id 
         ORDER BY ws2.session_id DESC 
         LIMIT 1),
        wo.status
      ) AS wor_status,
      wo.date_time AS date_requested,
      MIN(ws.work_start) AS first_start
  FROM work_orders wo
  LEFT JOIN work_sessions ws ON wo.id = ws.wor_id
  WHERE DATE(wo.date_time) BETWEEN :start AND :end
  GROUP BY wo.wor_number, wo.driver_name, wo.tanker_code, wo.plate_no, wo.date_time, wo.status
  ORDER BY wo.date_time DESC
");

$stmt->execute(['start' => $start, 'end' => $end]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* 🧮 Accurate Working Time (Excludes non-working hours & Sundays)
   - Mon–Fri: 07:15–17:00 (with breaks)
   - Sat: 07:15–11:30 (with 10:00–10:15 break)
   - Skip Sundays entirely
*/
function computeWorkingTime($start, $end) {
    if (empty($start) || empty($end)) return "0h 00m";
    $startTime = strtotime($start);
    $endTime   = strtotime($end);
    if ($endTime <= $startTime) return "0h 00m";

    $totalMinutes = 0;
    $current = $startTime;

    while ($current < $endTime) {
        $dayOfWeek = date('N', $current); // 1=Mon … 7=Sun
        if ($dayOfWeek == 7) { // skip Sundays
            $current = strtotime('next Monday', $current);
            continue;
        }

        // Define work schedule
        if ($dayOfWeek == 6) { // Saturday
            $workStart = strtotime(date('Y-m-d', $current) . " 07:15:00");
            $workEnd   = strtotime(date('Y-m-d', $current) . " 11:30:00");
            $breaks = [['start' => '10:00', 'end' => '10:15']];
        } else { // Monday–Friday
            $workStart = strtotime(date('Y-m-d', $current) . " 07:15:00");
            $workEnd   = strtotime(date('Y-m-d', $current) . " 17:00:00");
            $breaks = [
                ['start' => '10:00', 'end' => '10:15'],
                ['start' => '12:00', 'end' => '13:00'],
                ['start' => '15:00', 'end' => '15:15']
            ];
        }

        // Define overlap between this day's work window and the actual time range
        $from = max($current, $workStart);
        $to   = min($endTime, $workEnd);

        if ($to > $from) {
            $worked = ($to - $from) / 60; // minutes

            // Deduct breaks that overlap
            foreach ($breaks as $b) {
                $bStart = strtotime(date('Y-m-d', $current) . " {$b['start']}:00");
                $bEnd   = strtotime(date('Y-m-d', $current) . " {$b['end']}:00");
                if ($from < $bEnd && $to > $bStart) {
                    $overlapStart = max($from, $bStart);
                    $overlapEnd   = min($to, $bEnd);
                    $worked -= max(0, ($overlapEnd - $overlapStart) / 60);
                }
            }

            if ($worked > 0) $totalMinutes += $worked;
        }

        // Move to next day start (7:15 AM)
        $nextDay = strtotime('+1 day', strtotime(date('Y-m-d', $current)));
        $current = strtotime(date('Y-m-d', $nextDay) . " 07:15:00");
    }

    // Convert to readable format
    $hours = floor($totalMinutes / 60);
    $minutes = $totalMinutes % 60;
    return sprintf("%dh %02dm", $hours, $minutes);
}

/* 📊 Summary Calculations — using working-hour logic (same as table) */
$totalWORs = count($rows);
$pendingDays = [];

foreach ($rows as $r) {
    $pendingLabel = ($r['first_start'])
        ? computeWorkingTime($r['date_requested'], $r['first_start'])
        : computeWorkingTime($r['date_requested'], date('Y-m-d H:i:s'));

    // Convert "7h 24m" → total minutes → working days (8.5h = 510min)
    if (preg_match('/(\d+)h\s*(\d+)m/', $pendingLabel, $m)) {
        $minutes = ($m[1] * 60) + $m[2];
        $pendingDays[] = $minutes / 510;
    }
}

$longestPending = $pendingDays ? round(max($pendingDays), 1) : 0;
$averagePending = $pendingDays ? round(array_sum($pendingDays) / count($pendingDays), 1) : 0;
?>

<style>
.report-card {
  background:#fff;
  border-radius:6px;
  padding:15px 20px;
  box-shadow:0 2px 6px rgba(0,0,0,0.08);
  margin-bottom:15px;
  border:1px solid #dee2e6;
}
h6.fw-bold.text-success { font-weight:600;font-size:15px;color:#198754!important; }
.date-filter { display:flex;align-items:center;justify-content:flex-end;gap:6px;margin-bottom:10px; }
.date-filter label { font-weight:600;font-size:13px;margin-bottom:0; }
.date-filter input { width:140px;font-size:13px;padding:3px 5px; }
.summary-row .btn { font-size:13px;padding:5px 8px;font-weight:600; }
.table { font-size:13px;text-align:center;border-collapse:collapse!important;border:1px solid #dee2e6!important; }
.table td, .table th { text-align:center!important;vertical-align:middle!important;padding:6px 10px!important;border:1px solid #dee2e6!important; }
.table thead th { background-color:#0b5ed7!important;color:#fff!important;font-weight:600;border:1px solid #0b5ed7!important; }
.table tbody tr:hover { background-color:#f2f6ff!important;transition:0.2s; }
.dt-buttons .btn { background:#fff!important;border:1px solid #ccc!important;color:#333!important;font-size:13px;padding:4px 8px;margin-right:4px;border-radius:4px; }
.dt-buttons .btn:hover { background:#f8f9fa!important; }
</style>

<div class="report-card">
  <!-- 🔹 Date Filter -->
  <div class="date-filter">
    <label>Start:</label>
    <input type="date" id="start_date" value="<?= htmlspecialchars($start) ?>" class="form-control form-control-sm">
    <label>End:</label>
    <input type="date" id="end_date" value="<?= htmlspecialchars($end) ?>" class="form-control form-control-sm">
    <button id="filterPending" class="btn btn-primary btn-sm"><i class="fa fa-filter"></i></button>
  </div>

  <!-- 🧾 Title + Summary -->
  <div class="summary-bar mb-2 text-start">
    <h6 class="fw-bold text-success mb-2"><i class="fa fa-clock me-1"></i> Work Orders Report</h6>
    <div class="d-flex flex-wrap gap-2 summary-row">
      <button class="btn btn-outline-primary btn-sm"><i class="fa fa-list"></i> Total WOs: <b><?= $totalWORs ?></b></button>
      <button class="btn btn-outline-danger btn-sm"><i class="fa fa-hourglass-half"></i> Longest Pending: <b><?= $longestPending ?> working days</b></button>
      <button class="btn btn-outline-success btn-sm"><i class="fa fa-chart-line"></i> Avg Pending: <b><?= $averagePending ?> working days</b></button>
    </div>
  </div>

  <!-- 📋 Table -->
  <div class="table-responsive">
    <table id="pendingReport" class="table table-bordered table-striped table-sm align-middle text-center">
      <thead>
        <tr>
          <th>WOR #</th>
          <th>Driver</th>
          <th>Tanker</th>
          <th>Plate #</th>
          <th>Status</th>
          <th>Date Requested</th>
          <th>First Work Start</th>
          <th>Pending Duration</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($rows): ?>
          <?php foreach ($rows as $r): ?>
            <?php 
              $pendingLabel = $r['first_start'] 
                ? computeWorkingTime($r['date_requested'], $r['first_start'])
                : computeWorkingTime($r['date_requested'], date('Y-m-d H:i:s'));
            ?>
            <tr>
              <td><?= htmlspecialchars($r['wor_number']) ?></td>
              <td><?= htmlspecialchars($r['driver_name']) ?></td>
              <td><?= htmlspecialchars($r['tanker_code']) ?></td>
              <td><?= htmlspecialchars($r['plate_no']) ?></td>
              <td>
                <?php 
                  $status = trim($r['wor_status'] ?? '');
                  if ($status === '' || is_null($status)) $status = 'On Hold';
                  $badge = match($status) {
                      'Completed'   => 'success',
                      'In Progress' => 'info',
                      'On Hold'     => 'secondary',
                      'Pending'     => 'warning',
                      default       => 'secondary'
                  };
                  echo "<span class='badge bg-{$badge}'>$status</span>";
                ?>
              </td>
              <td><?= htmlspecialchars($r['date_requested']) ?></td>
              <td><?= $r['first_start'] ? date('Y-m-d H:i', strtotime($r['first_start'])) : '<em class="text-muted">Not Started</em>' ?></td>
              <td class="fw-bold text-primary"><?= $pendingLabel ?></td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="8" class="text-center text-muted">No work orders found for this date range.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
$(document).ready(function() {
  if ($.fn.DataTable.isDataTable('#pendingReport')) {
    $('#pendingReport').DataTable().destroy();
  }

  $('#pendingReport').DataTable({
    pageLength: 20,
    order: [[5, 'desc']],
    dom: '<"d-flex justify-content-between align-items-center mb-2"Bf>rtip',
    buttons: [
      {
        extend: 'excelHtml5',
        title: 'TEC Fuel & Energy Solutions Inc. - Pending Work Orders',
        className: 'btn btn-success btn-sm mr-1',
        text: '<i class="fa fa-file-excel"></i> Excel'
      },
      {
        extend: 'pdfHtml5',
        title: 'TEC Fuel & Energy Solutions Inc. - Pending Work Orders',
        orientation: 'landscape',
        pageSize: 'A4',
        className: 'btn btn-danger btn-sm mr-1',
        text: '<i class="fa fa-file-pdf"></i> PDF',
        customize: function (doc) {
          doc.content.push({
            text: '© 2025 JJJ Creations @ TEC Fuel & Energy Solutions Inc. All Rights Reserved.',
            style: 'footer',
            alignment: 'center',
            margin: [0, 10, 0, 0]
          });
          doc.styles.footer = { fontSize: 9, italics: true };
        }
      },
      {
        extend: 'print',
        title: '<h3>TEC Fuel & Energy Solutions Inc.<br>Pending Work Orders Report</h3>',
        className: 'btn btn-primary btn-sm',
        text: '<i class="fa fa-print"></i> Print',
        customize: function (win) {
          $(win.document.body).append(`
            <div style="text-align:center; margin-top:20px; font-size:10px; color:#555;">
              © 2025 JJJ Creations @ TEC Fuel & Energy Solutions Inc. All Rights Reserved.
            </div>
          `);
        }
      }
    ],
    language: { search: "Search:" },
    initComplete: function() {
      $('#pendingReport_wrapper').append(`
        <div class="text-center mt-3 text-muted small">
          © 2025 JJJ Creations @ TEC Fuel & Energy Solutions Inc. All Rights Reserved.
        </div>
      `);
    }
  });

  $('#filterPending').click(function() {
    const start = $('#start_date').val();
    const end = $('#end_date').val();
    $('#reportContainer').load('admin_pending_report.php?start_date=' + start + '&end_date=' + end);
  });
});
</script>