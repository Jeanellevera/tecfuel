<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'mechanic') {
  header("Location: login.php?error=Unauthorized");
  exit();
}
require "DB_connection.php";

$mechanic_id = $_SESSION['id'];

/* 🧭 Show only mechanic's own In Progress or Completed sessions */
$sql = "
  SELECT 
    ws.session_id,
    ws.activity,
    ws.remarks,
    ws.work_start,
    ws.work_end,
    ws.status AS session_status,
    ws.updated_at,
    wo.id AS wor_id,
    wo.wor_number,
    wo.tanker_code,
    wo.plate_no,
    wo.symptoms,
    wo.urgency,
    wo.date_time AS date_requested,
    u.full_name AS driver_name,
    wo.odo

  FROM work_sessions ws
  INNER JOIN (
      SELECT wor_id, MAX(session_id) AS latest_session
      FROM work_sessions
      GROUP BY wor_id
  ) latest ON ws.session_id = latest.latest_session
  JOIN work_orders wo ON wo.id = ws.wor_id
  LEFT JOIN users u ON wo.driver_id = u.id

  WHERE 
    (
      ws.status != 'Completed'
      OR ws.mechanic_id = :mech_id
    )
  ORDER BY ws.updated_at DESC
";


$stmt = $conn->prepare($sql);
$stmt->execute([':mech_id' => $mechanic_id]);
$sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Added Tasks | Motorpool / Fleet</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="css/style.css">
  <style>
    body { background-color: #f4f6f9; }
    .section-1 { padding: 20px; }
    .badge-warning { color:#111!important; }
    .modal-xl { max-width: 50%; }
    .modal-dialog-scrollable .modal-body { max-height: calc(100vh - 200px); overflow-y: auto; }
    .modal-footer { position: sticky; bottom: 0; background: #fff; border-top: 1px solid #ddd; z-index: 2; }

    /* ✅ Center headers & data */
    #addedTasksTable th, #addedTasksTable td {
      text-align: center !important;
      vertical-align: middle !important;
    }

    /* ✅ Pagination style */
    .dataTables_wrapper .dataTables_paginate .paginate_button {
      padding: 4px 8px;
      border-radius: 4px;
      margin: 0 2px;
    }
    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
      background-color: #007bff !important;
      color: white !important;
      border: none !important;
    }
    .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
      background-color: #0056b3 !important;
      color: white !important;
    }
    .dataTables_wrapper .dataTables_paginate .paginate_button.first,
    .dataTables_wrapper .dataTables_paginate .paginate_button.last {
      display: none !important;
    }

    /* ✅ Hover highlight */
    #addedTasksTable tbody tr:hover {
      background-color: #f1f7ff !important;
    }
     #miniRequestTable th:first-child,
  #miniRequestTable td:first-child {
    display: none;
  }

  #miniReturnTable th:first-child,
  #miniReturnTable td:first-child {
    display: none;
  }
  </style>
</head>
<body>

<input type="checkbox" id="checkbox">
<?php include "inc/header.php"; ?>
<div class="body">
  <?php include "inc/nav.php"; ?>

  <section class="section-1">
    <div class="card shadow-sm">
      <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0"></i> My Added Tasks</h5>
        <div class="d-flex align-items-center">
          <input id="searchBox" type="text" class="form-control form-control-sm mr-2" placeholder="Search...">
          <select id="urgencyFilter" class="custom-select custom-select-sm mr-2" style="width:auto;">
            <option value="">All Urgencies</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
          <button id="resetBtn" class="btn btn-light btn-sm"><i class="fa fa-sync-alt"></i> Reset</button>
        </div>
      </div>

      <div class="card-body p-0">
        <div class="table-responsive">
          <table id="addedTasksTable" class="table table-striped table-hover table-bordered mb-0">
            <thead class="thead-dark">
              <tr>
                <th>Date & Time</th>
                <th>WOR #</th>
                <th>Driver</th>
                <th>Tanker Code</th>
                <th>Symptoms</th>
                <th>Urgency</th>
                <th>Activity</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($sessions)): ?>
                <?php foreach ($sessions as $row): ?>
                  <tr>
                    <td>
                      <?= !empty($row['updated_at']) ? date('Y-m-d H:i:s', strtotime($row['updated_at'])) : '<span class="text-muted">-</span>'; ?>
                    </td>
                    <td><?= htmlspecialchars($row['wor_number']) ?></td>
                    <td><?= htmlspecialchars($row['driver_name']) ?></td>
                    <td><?= htmlspecialchars($row['tanker_code']) ?></td>
                    <td><?= htmlspecialchars($row['symptoms']) ?></td>
                    <td>
                      <?php
                        $urg = ucfirst($row['urgency'] ?? 'N/A');
                        $badge = ($urg === "High") ? "danger" : (($urg === "Medium") ? "warning" : "success");
                      ?>
                      <span class="badge badge-<?= $badge ?>"><?= $urg ?></span>
                    </td>
                    <td><?= htmlspecialchars($row['activity'] ?? '-') ?></td>
                    <td>
                     <?php
                        if ($row['session_status'] === 'Completed') {
                          echo '<span class="badge badge-success">Completed</span>';
                        } elseif ($row['session_status'] === 'On Hold') {
                          echo '<span class="badge badge-secondary">On Hold</span>';
                        } elseif ($row['session_status'] === 'Pending') {
                          echo '<span class="badge badge-info text-dark">Pending</span>';
                        } else {
                          echo '<span class="badge badge-warning text-dark">In Progress</span>';
                        }
                      ?>

                    </td>
                    <td>
                      <button class="btn btn-sm <?= ($row['session_status'] === 'Completed') ? 'btn-secondary' : 'btn-warning' ?>"
                        onclick='openEditModal(<?= json_encode($row) ?>)'>
                        <i class="fa <?= ($row['session_status'] === "Completed") ? "fa-eye" : "fa-edit" ?>"></i>
                        <?= ($row['session_status'] === "Completed") ? "View" : "Edit" ?>
                      </button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <!-- Leave tbody empty for DataTables emptyTable message -->
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
</div>

<?php include "mechanic-task-modals.php"; ?>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
function openEditModal(row) {
  console.log("🧭 Opening modal for WOR:", row.wor_number, "WOR ID:", row.wor_id);

  // 🔹 Fill modal base info
  $('#m_wor_id').val(row.wor_id);
  $('#m_wor').val(row.wor_number);
  $('#m_date_requested').val(row.date_requested || row.date_time || '');
  $('#m_driver').val(row.driver_name);
  $('#m_tanker').val(row.tanker_code);
  $('#m_plate').val(row.plate_no);
  $('#m_odo').val(row.odo);
  $('#m_symptoms').val(row.symptoms);
  $('#m_urgency').val(row.urgency);
  $('#m_activity').val(row.activity);
  $('#m_status').val(row.session_status);
  $('#m_start').val(row.work_start ? row.work_start.replace(' ', 'T') : '');
  $('#m_end').val(row.work_end ? row.work_end.replace(' ', 'T') : '');
  $('#m_remarks').val(row.remarks);

  /* ------------------------------------
     🧾 Fetch Requested Items & Returned Parts
  ------------------------------------- */
  $.getJSON("fetch_workorder_full.php", { wor_id: row.wor_id }, function(res) {
    console.log("✅ Response:", res);

    const reqBody = $("#miniRequestTable tbody");
    const retBody = $("#miniReturnTable tbody");
    reqBody.empty();
    retBody.empty();
    
  /* 🧾 Fill Test & Release Dates if present */
  if (res.mechanic_section) {
    const ms = res.mechanic_section;

    // 🔹 Show inspection block if activity is Inspection
    if (ms.activity === 'Inspection') {
      $('#inspectionBlock').show();
    }

    // 🔹 Fill test & release date values (convert MySQL format → HTML datetime-local)
    $('#m_test').val(ms.test_date ? ms.test_date.replace(' ', 'T') : '');
    $('#m_release').val(ms.release_date ? ms.release_date.replace(' ', 'T') : '');
  }

    // ✅ Requested Items
    if (res.requested_items && res.requested_items.length > 0) {
      res.requested_items.forEach((r, i) => {
        reqBody.append(`
          <tr>
            <td>${i + 1}</td>
            <td><input type="number" class="form-control form-control-sm" value="${r.qty || ''}"></td>
            <td><input type="text" class="form-control form-control-sm" value="${r.unit || ''}"></td>
            <td><input type="text" class="form-control form-control-sm" value="${r.item_description || ''}"></td>
            <td><button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">🗑</button></td>
          </tr>
        `);
      });
    } else {
      reqBody.html('<tr><td colspan="5" class="text-center text-muted">No requested items found</td></tr>');
    }

    // ✅ Returned Parts
    if (res.returned_parts && res.returned_parts.length > 0) {
      res.returned_parts.forEach((r, i) => {
        retBody.append(`
          <tr>
            <td>${i + 1}</td>
            <td><input type="text" class="form-control form-control-sm" value="${r.part_name || ''}"></td>
            <td><input type="text" class="form-control form-control-sm" value="${r.description || ''}"></td>
            <td><input type="number" class="form-control form-control-sm" value="${r.qty || ''}"></td>
            <td><input type="text" class="form-control form-control-sm" value="${r.unit || ''}"></td>
            <td>
              <select class="form-control form-control-sm">
                <option value="Usable" ${r.part_condition === 'Usable' ? 'selected' : ''}>Usable</option>
                <option value="Damage" ${r.part_condition === 'Damage' ? 'selected' : ''}>Damage</option>
              </select>
            </td>
            <td><input type="text" class="form-control form-control-sm" value="${r.remarks || ''}"></td>
            <td><button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">🗑</button></td>
          </tr>
        `);
      });
    } else {
      retBody.html('<tr><td colspan="8" class="text-center text-muted">No returned parts found</td></tr>');
    }

    /* 🔒 Lock all fields when completed */
    const isCompleted =
      (res.mechanic_section && res.mechanic_section.status === 'Completed') ||
      row.session_status === 'Completed' ||
      row.status === 'Completed';

    if (isCompleted) {
      console.log("🔒 Locking all fields (Completed)");
      $('#editModal input, #editModal select, #editModal textarea').prop('disabled', true);
      $('#miniRequestTable .btn, #miniReturnTable .btn, #editModal .btn-success, #editModal .btn-secondary').hide();
      $('#editModal .modal-header .modal-title').text('View Completed Work Order');
    } else {
      console.log("🔓 Editable mode");
      $('#editModal input, #editModal select, #editModal textarea').prop('disabled', false);
      $('#miniRequestTable .btn, #miniReturnTable .btn, #editModal .btn-success, #editModal .btn-secondary').show();
      $('#editModal .modal-header .modal-title').text('Edit Work Order');
    }

    // ✅ Show modal after everything is loaded
    $('#editModal').modal('show');
  }).fail(function(xhr, status, error) {
    console.error("❌ Fetch error:", status, error);
    alert("Failed to load requested/returned items.");
  });
}

/* ✅ DataTables setup */
$(document).ready(function() {
  const table = $('#addedTasksTable').DataTable({
    pageLength: 10,
    lengthChange: true,
    pagingType: "simple_numbers",
    language: {
      search: "",
      searchPlaceholder: "Search...",
      emptyTable: "No tasks found.",
      infoFiltered: ""
    },
    dom: '<"top"l>rt<"bottom"ip><"clear">'
  });

  $('#searchBox').on('keyup', function() {
    table.search(this.value).draw();
  });

  $('#urgencyFilter').on('change', function() {
    const urgency = this.value;
    if (urgency) {
      table.column(5).search('^' + urgency + '$', true, false).draw();
    } else {
      table.column(5).search('').draw();
    }
  });

  $('#resetBtn').on('click', function() {
    $('#searchBox').val('');
    $('#urgencyFilter').val('');
    table.search('').columns().search('').draw();
  });
});
$(document).ready(function () {

  // 🟢 When modal opens, check activity and toggle fields
  $('#editModal').on('shown.bs.modal', function () {

    const activity = $('#m_activity').val()?.toLowerCase().trim();

    // Show or hide the inspection block based on activity
    if (activity === 'inspection') {
      $('#inspectionBlock').show();
    } else {
      $('#inspectionBlock').hide();
    }

    // 🟢 Auto-fill existing values if available
    const testVal = $('#m_test').data('value') || $('#m_test').val();
    const releaseVal = $('#m_release').data('value') || $('#m_release').val();

    if (testVal) $('#m_test').val(testVal);
    if (releaseVal) $('#m_release').val(releaseVal);
  });

  // 🟡 If activity is changed manually
  $('#m_activity').on('change', function () {
    const selected = $(this).val()?.toLowerCase().trim();

    if (selected === 'inspection') {
      $('#inspectionBlock').slideDown(200);
    } else {
      $('#inspectionBlock').slideUp(200);
      $('#m_test').val('');
      $('#m_release').val('');
    }
  });
});

</script>
</body>
</html>