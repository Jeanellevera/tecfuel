<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "admin") {
  header("Location: login.php");
  exit();
}

include "DB_connection.php";

/* 🔹 Fetch all other works (pull duration from DB) */
$stmt = $conn->prepare("
  SELECT 
    ow.id,
    u.full_name AS mechanic_name,
    ow.description,
    ow.location,
    ow.work_category,
    ow.start_time,
    ow.end_time,
    ow.duration,
    ow.requested_by,
    ow.date_created
  FROM other_works ow
  LEFT JOIN users u ON ow.mechanic_id = u.id
  ORDER BY ow.date_created DESC
");
$stmt->execute();
$works = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Other Works | Admin</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.bootstrap4.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="css/style.css">
  <style>
    table.dataTable thead th,
    table.dataTable tbody td {
      text-align: center !important;
      vertical-align: middle !important;
    }
    .badge { font-size: 0.85rem; padding: 5px 10px; }
  </style>
</head>

<body>
  <input type="checkbox" id="checkbox">
  <?php include "inc/header.php"; ?>
  <div class="body">
    <?php include "inc/nav.php"; ?>

    <section class="section container-fluid mt-4">
      <div class="card shadow-sm border-0">
        <div class="card-header bg-white d-flex justify-content-between align-items-center border-bottom">
          <h5 class="mb-0"><i class="fa fa-briefcase text-primary"></i> Other Works</h5>
        </div>

        <div class="card-body">
          <?php if (empty($works)): ?>
            <div class="alert alert-info text-center mb-0">
              <i class="fa fa-info-circle"></i> No other works recorded yet.
            </div>
          <?php else: ?>
            <div class="table-responsive">
              <table id="otherWorksTable" class="table table-striped table-bordered text-center align-middle">
                <thead class="thead-dark">
                  <tr>
                    <th>#</th>
                    <th>Mechanic</th>
                    <th>Description</th>
                    <th>Location</th>
                    <th>Work Category</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                    <th>Duration</th>
                    <th>Requested By</th>
                    <th>Date Created</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i = 1; foreach ($works as $row): 
                    $durationDisplay = $row['duration'] ?: '-';
                    if ($durationDisplay === '-' && !empty($row['start_time']) && !empty($row['end_time'])) {
                      $start = new DateTime($row['start_time']);
                      $end = new DateTime($row['end_time']);
                      if ($end > $start) {
                        $mins = (int)(($end->getTimestamp() - $start->getTimestamp()) / 60);
                        $durationDisplay = sprintf("%d hr %02d min", floor($mins/60), $mins%60);
                      }
                    }
                  ?>
                    <tr>
                      <td><?= $i++ ?></td>
                      <td><?= htmlspecialchars($row['mechanic_name']) ?></td>
                      <td><?= htmlspecialchars($row['description']) ?></td>
                      <td><?= htmlspecialchars($row['location']) ?></td>
                      <td>
                        <?php
                          $cat = htmlspecialchars($row['work_category']);
                          $badgeClass = match($cat) {
                            'Housekeeping' => 'info',
                            'Rescue' => 'danger',
                            'Misc Work' => 'warning',
                            'Misload' => 'primary',
                            default => 'secondary'
                          };
                          echo "<span class='badge badge-$badgeClass'>$cat</span>";
                        ?>
                      </td>
                      <td><?= $row['start_time'] ? date('M d, Y h:i A', strtotime($row['start_time'])) : '-' ?></td>
                      <td><?= $row['end_time'] ? date('M d, Y h:i A', strtotime($row['end_time'])) : '-' ?></td>
                      <td><?= htmlspecialchars($durationDisplay) ?></td>
                      <td><?= htmlspecialchars($row['requested_by'] ?: '-') ?></td>
                      <td><?= date('M d, Y h:i A', strtotime($row['date_created'])) ?></td>
                      <td>
                        <button class="btn btn-sm btn-primary editBtn" 
                                data-id="<?= $row['id'] ?>" 
                                data-desc="<?= htmlspecialchars($row['description']) ?>" 
                                data-loc="<?= htmlspecialchars($row['location']) ?>" 
                                data-cat="<?= htmlspecialchars($row['work_category']) ?>" 
                                data-start="<?= $row['start_time'] ?>" 
                                data-end="<?= $row['end_time'] ?>" 
                                data-req="<?= htmlspecialchars($row['requested_by']) ?>">
                          <i class="fa fa-edit"></i>
                        </button>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </section>
  </div>

  <!-- 🛠️ Edit Modal -->
  <div class="modal fade" id="editWorkModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <form id="editWorkForm" class="modal-content">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title">Edit Other Work</h5>
          <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id" id="edit_id">
          <div class="form-group">
            <label>Description</label>
            <textarea name="description" id="edit_description" class="form-control" required></textarea>
          </div>
          <div class="form-group">
            <label>Location</label>
            <input type="text" name="location" id="edit_location" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Work Category</label>
            <select name="work_category" id="edit_category" class="form-control" required>
              <option value="">Select Category</option>
              <option value="Misc Work">Misc Work</option>
              <option value="Rescue">Rescue</option>
              <option value="Housekeeping">Housekeeping</option>
              <option value="Misload">Misload</option>
            </select>
          </div>
          <div class="form-group">
            <label>Start Time</label>
            <input type="datetime-local" name="start_time" id="edit_start" class="form-control">
          </div>
          <div class="form-group">
            <label>End Time</label>
            <input type="datetime-local" name="end_time" id="edit_end" class="form-control">
          </div>
          <div class="form-group">
            <label>Requested By</label>
            <input type="text" name="requested_by" id="edit_requested" class="form-control">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm">Update</button>
        </div>
      </form>
    </div>
  </div>

<!-- ✅ JS Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
  // 🧭 DataTable Init
  $('#otherWorksTable').DataTable({
    order: [[9, 'desc']],
    pageLength: 10,
    dom: '<"d-flex justify-content-between align-items-center mb-2"Bf>rtip',
    buttons: []
  });

  // 🧩 Open Edit Modal
  $(document).on('click', '.editBtn', function() {
    const btn = $(this);
    $('#edit_id').val(btn.data('id'));
    $('#edit_description').val(btn.data('desc'));
    $('#edit_location').val(btn.data('loc'));
    $('#edit_category').val(btn.data('cat'));
    $('#edit_start').val(btn.data('start'));
    $('#edit_end').val(btn.data('end'));
    $('#edit_requested').val(btn.data('req'));
    $('#editWorkModal').modal('show');
  });

  // 🧩 Submit Update
  $('#editWorkForm').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
      url: 'update_other_work.php',
      method: 'POST',
      data: $(this).serialize(),
      success: function(res) {
        let r = JSON.parse(res);
        if (r.success) {
          Swal.fire({ icon: 'success', title: 'Updated!', text: r.message, timer: 1500, showConfirmButton: false });
          $('#editWorkModal').modal('hide');
          setTimeout(() => location.reload(), 1600);
        } else {
          Swal.fire({ icon: 'error', title: 'Update Failed', text: r.message });
        }
      },
      error: function() {
        Swal.fire({ icon: 'error', title: 'Server Error', text: 'Unable to update entry.' });
      }
    });
  });
});
</script>

</body>
</html>
