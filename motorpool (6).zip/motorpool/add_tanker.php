<?php
session_start();
include "DB_connection.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $tanker_code = trim($_POST['tanker_code']);
    $plate_no    = trim($_POST['plate_no']);

    if ($tanker_code == "" || $plate_no == "") {
        echo json_encode(["success" => false, "message" => "All fields are required."]);
        exit;
    }

    try {
        $stmt = $conn->prepare("INSERT INTO tankers (tanker_code, plate_no) VALUES (?, ?)");
        $stmt->execute([$tanker_code, $plate_no]);

        echo json_encode([
            "success" => true,
            "data" => ["tanker_code" => $tanker_code, "plate_no" => $plate_no]
        ]);
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "message" => "Error: " . $e->getMessage()]);
    }
}
