<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once "DB_connection.php";

/* 🗓 Date Filters */
$from = isset($_GET['from']) ? $_GET['from'] : date('Y-m-01');
$to   = isset($_GET['to'])   ? $_GET['to']   : date('Y-m-d');

/* 🧾 Requested Items — join work_orders to get tanker details */
$sqlReq = "
  SELECT 
      ri.date_requested AS dt,
      ri.wor_number,
      wo.tanker_code,
      ri.item_description AS item,
      ri.qty AS qty,
      ri.unit,
      'Requested' AS kind
  FROM requested_items ri
  LEFT JOIN work_orders wo ON ri.wor_number = wo.wor_number
  WHERE DATE(ri.date_requested) BETWEEN ? AND ?
";

/* 🔁 Returned Parts — join work_orders to get tanker details */
$sqlRet = "
  SELECT 
      rp.date_returned AS dt,
      rp.wor_number,
      wo.tanker_code,
      rp.part_name AS item,
      rp.qty AS qty,
      rp.unit,
      CONCAT('Returned (', rp.part_condition, ')') AS kind
  FROM returned_parts rp
  LEFT JOIN work_orders wo ON rp.wor_number = wo.wor_number
  WHERE DATE(rp.date_returned) BETWEEN ? AND ?
";

/* ⚙️ Execute Queries */
$req = $conn->prepare($sqlReq);
$req->execute([$from, $to]);
$rowsReq = $req->fetchAll(PDO::FETCH_ASSOC);

$ret = $conn->prepare($sqlRet);
$ret->execute([$from, $to]);
$rowsRet = $ret->fetchAll(PDO::FETCH_ASSOC);

/* 📊 Merge & Sort */
$rows = array_merge($rowsReq, $rowsRet);
usort($rows, fn($a, $b) => strcmp($b['dt'], $a['dt']));

/* 📈 Totals (Fixed logic) */
$totalRequested = $conn->prepare("
  SELECT COALESCE(SUM(qty),0) 
  FROM requested_items 
  WHERE DATE(date_requested) BETWEEN ? AND ?
");
$totalRequested->execute([$from, $to]);
$totalRequested = (int)$totalRequested->fetchColumn();

/* 🧮 FIXED: Count total returned records, not quantity */
$totalReturned = $conn->prepare("
  SELECT COALESCE(COUNT(*),0) 
  FROM returned_parts 
  WHERE DATE(date_returned) BETWEEN ? AND ?
");
$totalReturned->execute([$from, $to]);
$totalReturned = (int)$totalReturned->fetchColumn();
?>


<style>
.report-card {
  background: #fff;
  border-radius: 6px;
  padding: 15px 20px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
  margin-bottom: 15px;
}

/* 🔹 Title + Summary */
.summary-bar h6 {
  font-weight: 600;
  color: #0d6dfdcf;
  margin-bottom: 8px;
}
.summary-bar .btn {
  font-size: 13px;
  padding: 5px 8px;
  font-weight: 600;
}

/* 🗓 Date Filter (Right-Aligned) */
.date-filter {
  display: flex;
  align-items: center;
  gap: 6px;
  justify-content: flex-end;
  margin-bottom: 8px;
}
.date-filter label {
  font-weight: 600;
  font-size: 13px;
  margin-bottom: 0;
}
.date-filter input {
  width: 140px;
  font-size: 13px;
  padding: 3px 5px;
}

/* 📋 Table Formatting */
.table {
  font-size: 13px;
  margin-bottom: 0;
  text-align: center;
}
.table td, .table th {
  text-align: center !important;
  vertical-align: middle !important;
  padding: 6px 10px !important;
}
.table thead th {
  background-color: #0d6dfdcf !important;
  color: #fff !important;
  font-weight: 600;
}

/* ⚪ Export Buttons */
.dt-buttons .btn {
  background: #fff !important;
  border: 1px solid #ccc !important;
  color: #333 !important;
  font-size: 13px;
  padding: 4px 8px;
  margin-right: 4px;
  border-radius: 4px;
}
.dt-buttons .btn:hover {
  background: #f8f9fa !important;
}

/* 🔹 DataTables Styling */
.dataTables_wrapper .dataTables_filter input {
  height: 26px;
  font-size: 13px;
}
.dataTables_wrapper .dataTables_info {
  font-size: 12px;
  color: #555;
}
</style>

<div class="report-card">
  <!-- 🗓 Date Filter -->
  <div class="date-filter">
    <label>Start:</label>
    <input type="date" id="parts_from" value="<?= htmlspecialchars($from) ?>" class="form-control form-control-sm">
    <label>End:</label>
    <input type="date" id="parts_to" value="<?= htmlspecialchars($to) ?>" class="form-control form-control-sm">
    <button id="parts_apply" class="btn btn-primary btn-sm"><i class="fa fa-filter"></i></button>
  </div>


<!-- 🧾 Title + Summary (Left-Aligned Like Labor Hours) -->
<div class="summary-bar mb-2 text-start">
  <h6 class="fw-bold text-success mb-2" style="font-size:15px; text-align:left;">
    <i class="fa fa-cogs me-1"></i> Parts Usage Report
  </h6>

  <div class="d-flex flex-wrap gap-2">
    <button class="btn btn-outline-primary btn-sm d-flex align-items-center">
      <i class="fa fa-arrow-up me-1"></i>
      <span>Requested:</span>&nbsp;<b><?= number_format($totalRequested) ?></b>
    </button>

    <button class="btn btn-outline-success btn-sm d-flex align-items-center">
      <i class="fa fa-arrow-down me-1"></i>
      <span>Returned:</span>&nbsp;<b><?= number_format($totalReturned) ?></b>
    </button>

    <button class="btn btn-outline-info btn-sm d-flex align-items-center">
      <i class="fa fa-exchange me-1"></i>
      <span>Net Outflow:</span>&nbsp;<b><?= number_format($totalRequested - $totalReturned) ?></b>
    </button>
  </div>
</div>



  <!-- 📋 Table -->
  <div class="table-responsive">
    <table id="partsTable" class="table table-bordered table-striped table-sm text-center align-middle">
      <thead>
        <tr>
          <th>Date & Time</th>
          <th>WOR #</th>
          <th>Tanker</th>
          <th>Item</th>
          <th>Qty</th>
          <th>Unit</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
  <?php if (!empty($rows)): ?>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= htmlspecialchars(date('Y-m-d H:i', strtotime($r['dt']))) ?></td>
        <td><?= htmlspecialchars($r['wor_number'] ?? 'N/A') ?></td>
        <td><?= htmlspecialchars($r['tanker_code'] ?? 'N/A') ?></td>
        <td><?= htmlspecialchars($r['item'] ?? '-') ?></td>
        <td><?= htmlspecialchars($r['qty'] ?? 0) ?></td>
        <td><?= htmlspecialchars($r['unit'] ?? '-') ?></td>
        <td><?= htmlspecialchars($r['kind'] ?? '-') ?></td>
      </tr>
    <?php endforeach; ?>
  <?php endif; ?>
  <!-- 🔸 If empty, leave <tbody> literally empty.
       DataTables will render the “No data available in table” row for us. -->
</tbody>
    </table>
  </div>
</div>

<!-- ✅ DataTables Script -->
<script>
$(document).ready(function() {
  if ($.fn.DataTable.isDataTable('#partsTable')) {
    $('#partsTable').DataTable().destroy();
  }

  $('#partsTable').DataTable({
    pageLength: 25,
    order: [[0, 'desc']],
    dom: '<"d-flex justify-content-between align-items-center mb-2"Bf>rtip',
    buttons: [
      { extend: 'excelHtml5', title: 'TEC Fuel & Energy Solutions Inc. - Parts Report',
        className: 'btn btn-light btn-sm', text: '<i class="fa fa-file-excel-o"></i> Excel' },
      { extend: 'pdfHtml5', title: 'TEC Fuel & Energy Solutions Inc. - Parts Report',
        orientation: 'landscape', pageSize: 'A4',
        className: 'btn btn-light btn-sm', text: '<i class="fa fa-file-pdf-o"></i> PDF',
        customize: function (doc) {
          doc.content.push({
            text: '© 2025 JJJ Creations @ TEC Fuel & Energy Solutions Inc. All Rights Reserved.',
            style: 'footer', alignment: 'center', margin: [0, 10, 0, 0]
          });
          doc.styles.footer = { fontSize: 9, italics: true, color: '#555' };
        } },
      { extend: 'print', title: '<h3>TEC Fuel & Energy Solutions Inc.<br>Parts Report</h3>',
        className: 'btn btn-light btn-sm', text: '<i class="fa fa-print"></i> Print',
        customize: function (win) {
          $(win.document.body).find('h3').css({
            'text-align': 'center','font-size': '18px','margin-bottom': '10px','font-weight': 'bold'
          });
          $(win.document.body).append(
            '<div style="text-align:center; margin-top:30px; font-size:10px; color:#555;">© 2025 JJJ Creations @ TEC Fuel & Energy Solutions Inc. All Rights Reserved.</div>'
          );
        } }
    ],
    language: {
      search: "Search:",
      emptyTable: "No data available in table",   // ✅ what you want
      zeroRecords: "No matching records found"    // for filtered-empty
    }
  });

  $('#parts_apply').on('click', function() {
    const from = $('#parts_from').val();
    const to = $('#parts_to').val();
    $('#reportContainer').load('admin_parts_report.php?from=' + from + '&to=' + to);
  });
});

</script>