<?php 
session_start();
if (isset($_POST['user_name']) && isset($_POST['password'])) {
    include "../DB_connection.php";

    function validate_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $user_name = validate_input($_POST['user_name']);
    $password  = validate_input($_POST['password']);

    if (empty($user_name)) {
        $em = "User name is required";
        header("Location: ../login.php?error=$em");
        exit();
    } else if (empty($password)) {
        $em = "Password is required";
        header("Location: ../login.php?error=$em");
        exit();
    } else {
        $sql = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$user_name]);

        if ($stmt->rowCount() == 1) {
            $user = $stmt->fetch();
            $usernameDb = $user['username'];
            $passwordDb = $user['password'];
            $role       = $user['role'];
            $id         = $user['id'];
            $status     = strtolower($user['status']); // ✅ added

            // ✅ Check if account is inactive
            if ($status !== 'active') {
                $em = "Account is inactive. Please contact admin.";
                header("Location: ../login.php?error=$em");
                exit();
            }

            if ($user_name === $usernameDb) {
                if (password_verify($password, $passwordDb)) {
                    // set session
                    $_SESSION['role']      = $role;
                    $_SESSION['id']        = $id;
                    $_SESSION['username']  = $usernameDb;
                    $_SESSION['full_name'] = $user['full_name'];

                    // ✅ Redirect user to correct dashboard
                    if ($role == "admin") {
                        header("Location: ../admin-dashboard.php");
                        exit();
                    } else if (in_array($role, ["driver", "mechanic", "warehouse"])) {
                        header("Location: ../index.php");
                        exit();
                    } else {
                        $em = "Unknown role. Please contact admin.";
                        header("Location: ../login.php?error=$em");
                        exit();
                    }
                } else {
                    $em = "Incorrect username or password";
                    header("Location: ../login.php?error=$em");
                    exit();
                }
            } else {
                $em = "Incorrect username or password";
                header("Location: ../login.php?error=$em");
                exit();
            }
        } else {
            $em = "Incorrect username or password";
            header("Location: ../login.php?error=$em");
            exit();
        }
    }
} else {
    $em = "Unknown error occurred";
    header("Location: ../login.php?error=$em");
    exit();
}
?>
