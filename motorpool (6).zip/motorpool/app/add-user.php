<?php
session_start();
header('Content-Type: application/json');

// ✅ Admin-only check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

include "../DB_connection.php";
include "Model/User.php";

try {
    // --- Input validation ---
    $full_name = trim($_POST['full_name'] ?? '');
    $username  = trim($_POST['username'] ?? '');
    $password  = trim($_POST['password'] ?? '');
    $role      = strtolower(trim($_POST['role'] ?? ''));
    $status    = strtolower(trim($_POST['status'] ?? 'active'));

    if ($full_name === '' || $username === '' || $password === '' || $role === '') {
        echo json_encode(['success' => false, 'message' => '⚠️ All fields are required.']);
        exit;
    }

    // ✅ Validate ENUMs
    $validRoles = ['admin', 'employee', 'driver', 'mechanic', 'warehouse'];
    $validStatus = ['active', 'inactive'];

    if (!in_array($role, $validRoles)) {
        echo json_encode(['success' => false, 'message' => '❌ Invalid role provided.']);
        exit;
    }

    if (!in_array($status, $validStatus)) {
        echo json_encode(['success' => false, 'message' => '❌ Invalid status provided.']);
        exit;
    }

    // ✅ Check if username already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => '⚠️ Username already exists.']);
        exit;
    }

    // ✅ Insert using Model
    $inserted = insert_user($conn, $full_name, $username, $password, $role, $status);

    if ($inserted) {
        echo json_encode(['success' => true, 'message' => '✅ New user added successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => '⚠️ Server error while saving user.']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
