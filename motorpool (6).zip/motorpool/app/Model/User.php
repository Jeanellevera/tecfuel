<?php
// ==========================================
//  User Model (Updated for Manage Users)
//  Works with ENUMs and lowercase values
// ==========================================

// ✅ Get all users (for admin)
function get_all_users($conn){
    try {
        $stmt = $conn->prepare("SELECT * FROM users ORDER BY id ASC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("get_all_users error: " . $e->getMessage());
        return [];
    }
}

// ✅ Get single user by ID
function get_user_by_id($conn, $id){
    try {
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: 0;
    } catch (PDOException $e) {
        error_log("get_user_by_id error: " . $e->getMessage());
        return 0;
    }
}

// ✅ Insert new user
function insert_user($conn, $full_name, $username, $password, $role, $status = 'active'){
    try {
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        $role = strtolower(trim($role));
        $status = strtolower(trim($status));

        $stmt = $conn->prepare("
            INSERT INTO users (full_name, username, password, role, status)
            VALUES (?, ?, ?, ?, ?)
        ");
        return $stmt->execute([$full_name, $username, $hashed, $role, $status]);
    } catch (PDOException $e) {
        error_log("insert_user error: " . $e->getMessage());
        return false;
    }
}

// ✅ Update existing user
function update_user($conn, $id, $full_name, $username, $password, $role, $status){
    try {
        $role = strtolower(trim($role));
        $status = strtolower(trim($status));

        if (!empty($password)) {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("
                UPDATE users
                SET full_name = ?, username = ?, password = ?, role = ?, status = ?
                WHERE id = ?
            ");
            return $stmt->execute([$full_name, $username, $hashed, $role, $status, $id]);
        } else {
            $stmt = $conn->prepare("
                UPDATE users
                SET full_name = ?, username = ?, role = ?, status = ?
                WHERE id = ?
            ");
            return $stmt->execute([$full_name, $username, $role, $status, $id]);
        }
    } catch (PDOException $e) {
        error_log("update_user error: " . $e->getMessage());
        return false;
    }
}

// ✅ Soft delete (toggle Active/Inactive)
function deactivate_user($conn, $id, $status = 'inactive'){
    try {
        $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ?");
        return $stmt->execute([$status, $id]);
    } catch (PDOException $e) {
        error_log("deactivate_user error: " . $e->getMessage());
        return false;
    }
}

// ✅ Count all users (optionally by role)
function count_users($conn, $role = null){
    try {
        if ($role) {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE role = ?");
            $stmt->execute([$role]);
        } else {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM users");
            $stmt->execute();
        }
        return $stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log("count_users error: " . $e->getMessage());
        return 0;
    }
}
?>
