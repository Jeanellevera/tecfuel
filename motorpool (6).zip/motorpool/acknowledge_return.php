<?php
session_start();
include "DB_connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $stmt = $conn->prepare("UPDATE returned_parts 
                            SET received_by = ?, date_received = NOW() 
                            WHERE id = ?");
    $stmt->execute([$_SESSION['id'], $_POST['id']]);

    echo json_encode(["success" => true, "message" => "Return acknowledged successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Invalid request"]);
}
?>
