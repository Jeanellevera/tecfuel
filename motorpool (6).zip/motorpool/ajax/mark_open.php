<?php
// ajax/mark_open.php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'mechanic') {
  http_response_code(403);
  header('Content-Type: application/json');
  echo json_encode(['ok' => false, 'error' => 'Forbidden']);
  exit;
}

header('Content-Type: application/json');

// ADJUST THIS PATH if needed (relative to THIS file)
require_once __DIR__ . '/../DB_connection.php';

$woId = isset($_POST['id']) ? (int)$_POST['id'] : 0;
if (!$woId) {
  echo json_encode(['ok' => false, 'error' => 'Missing id']); exit;
}

// Set start_date today only if it's NULL
$upd = $conn->prepare("
  UPDATE work_orders
  SET start_date = CURDATE()
  WHERE id = :id AND start_date IS NULL
");
$upd->execute([':id' => $woId]);

// Read back dates
$stmt = $conn->prepare("SELECT start_date, end_date FROM work_orders WHERE id=:id");
$stmt->execute([':id' => $woId]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row || !$row['start_date']) {
  echo json_encode(['ok'=>false,'error'=>'No start_date found']); exit;
}

$start = new DateTime($row['start_date']);
$end   = $row['end_date'] ? new DateTime($row['end_date']) : new DateTime('today');

// Inclusive day count; min 1 day
$days = $start->diff($end)->days + 1;
if ($days < 1) $days = 1;

echo json_encode([
  'ok'           => true,
  'start_date'   => $row['start_date'],
  'end_date'     => $row['end_date'],
  'pending_days' => $days
]);
