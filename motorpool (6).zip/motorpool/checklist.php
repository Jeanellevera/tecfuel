<?php
session_start();
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin', 'mechanic'])) {
  header("Location: login.php?error=Unauthorized Access");
  exit();
}

include "DB_connection.php";
include "app/Model/User.php";

/* 🗓 Default Date Range (This Week) */
$monday   = date('Y-m-d', strtotime('monday this week'));
$saturday = date('Y-m-d', strtotime('saturday this week'));
$start_date = isset($_GET['start_date']) && $_GET['start_date'] != '' ? $_GET['start_date'] : $monday;
$end_date   = isset($_GET['end_date'])   && $_GET['end_date']   != '' ? $_GET['end_date']   : $saturday;

/* 📅 Generate Dates in Range */
$dates = [];
$current = strtotime($start_date);
$end     = strtotime($end_date);
while ($current <= $end) {
  $dates[] = date('Y-m-d', $current);
  $current = strtotime('+1 day', $current);
}

/* 🚛 Depots and Tankers */
$depots  = ["KITROL", "JETTI", "PETRO DE ORO"];
$tankers = $conn->query("SELECT tanker_code FROM vehicles WHERE category='Tanker' AND status='active' ORDER BY tanker_code ASC")->fetchAll(PDO::FETCH_COLUMN);

/* 📋 Load Checklist Records */
$stmt = $conn->prepare("SELECT * FROM tanker_checklist WHERE checklist_date BETWEEN ? AND ?");
$stmt->execute([$start_date, $end_date]);
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* 🧩 Organize Data by [tanker][date][depot] */
$data = [];
foreach ($records as $r) {
  $data[$r['tanker_code']][$r['checklist_date']][$r['depot']] = $r;
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Tanker Availability</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="css/style.css">
  <style>
    html, body {
      overflow-x: hidden !important;
      background-color: #f4f6f9;
    }
    .card {
      border-radius: 8px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    .filter-bar {
      background: #fff;
      border-bottom: 1px solid #ddd;
      padding: 10px 12px;
    }
    .filter-bar form {
      display: flex;
      align-items: center;
      gap: 5px;
      flex-wrap: wrap;
    }
    .table-container {
      overflow-x: auto;
      overflow-y: auto;
      max-height: 70vh;
      background: #fff;
      border-radius: 6px;
      border: 1px solid #ddd;
    }
    .table thead th {
      background: #064670 !important;
      color: #fff !important;
      border: 1px solid #000 !important;
      position: sticky;
      top: 0;
      z-index: 3;
      text-align: center;
      vertical-align: middle;
      font-size: 13px;
    }
    .table td {
      border: 1px solid #000 !important;
      text-align: center;
      vertical-align: middle;
      font-size: 12px;
    }
    .badge[data-toggle="tooltip"] {
      pointer-events: auto;
    }
    .badge { font-size: 0.7rem; padding: 3px 6px; }
  </style>
</head>
<body>

<input type="checkbox" id="checkbox">
<?php include "inc/header.php"; ?>
<div class="body">
<?php include "inc/nav.php"; ?>

<section class="section-1">
  <!-- ✅ Title + Filter Bar -->
  <div class="filter-bar d-flex justify-content-between align-items-center mb-2">
    <h5 class="m-0"><i class="fa fa-check-circle text-primary"></i> Tanker Availability</h5>

    <div class="d-flex align-items-center flex-wrap">
      <?php if ($_SESSION['role'] === 'admin'): ?>
      <form method="GET" class="m-0">
        <label class="mr-1">Start:</label>
        <input type="date" name="start_date" value="<?= htmlspecialchars($start_date) ?>" required>
        <label class="ml-2 mr-1">End:</label>
        <input type="date" name="end_date" value="<?= htmlspecialchars($end_date) ?>" required>
        <button type="submit" class="btn btn-sm btn-primary ml-2"><i class="fa fa-filter"></i></button>
        <a href="checklist.php" class="btn btn-sm btn-secondary ml-1"><i class="fa fa-undo"></i></a>
      </form>

      <button class="btn btn-sm btn-warning ml-2" data-toggle="modal" data-target="#editChecklistModal">
        <i class="fa fa-edit"></i> Edit Checklist
      </button>
      <?php else: ?>
      <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#saveChecklistModal">
        <i class="fa fa-plus"></i> Add Checklist
      </button>
      <?php endif; ?>
    </div>
  </div>

  <!-- ✅ Scrollable Table -->
  <div class="card shadow-sm">
    <div class="card-body p-2">
      <div class="table-container">
        <table class="table table-bordered table-hover table-sm mb-0">
          <thead>
            <tr>
              <th>Tanker</th>
              <?php foreach ($dates as $d): ?>
                <th colspan="3"><?= date('M d, Y (D)', strtotime($d)) ?></th>
              <?php endforeach; ?>
            </tr>
            <tr>
              <th></th>
              <?php foreach ($dates as $d): ?>
                <?php foreach ($depots as $dep): ?>
                  <th><?= $dep ?></th>
                <?php endforeach; ?>
              <?php endforeach; ?>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($tankers as $t): ?>
              <tr>
                <td><b><?= htmlspecialchars($t) ?></b></td>
                <?php foreach ($dates as $d): ?>
                  <?php foreach ($depots as $dep): ?>
                    <td>
                      <?php if (isset($data[$t][$d][$dep]) && $data[$t][$d][$dep]['available']==1):
                        $rec=$data[$t][$d][$dep];
                        $tip="Created by: ".htmlspecialchars($rec['created_by'])." on ".date("M d, Y H:i",strtotime($rec['created_at']));
                        if(!empty($rec['edited_by'])){$tip.=" | Edited by: ".htmlspecialchars($rec['edited_by'])." on ".date("M d, Y H:i",strtotime($rec['edited_at']));}
                      ?>
                        <span class="badge badge-success" data-toggle="tooltip" title="<?= $tip ?>">Available</span>
                      <?php else: ?>- <?php endif; ?>
                    </td>
                  <?php endforeach; ?>
                <?php endforeach; ?>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>
</div>

<?php if ($_SESSION['role'] == "admin"): ?>
<div class="modal fade" id="editChecklistModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered" style="max-width: 900px;">
    <div class="modal-content">
      <form id="editChecklistForm" method="POST" action="save_checklist.php">
        <div class="modal-header bg-warning">
          <h5 class="modal-title text-dark"><i class="fa fa-edit"></i> Edit Tanker Availability</h5>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <div class="modal-body">
          <label class="font-weight-bold">Select Date:</label>
          <input type="date" name="checklist_date" id="checklist_date" class="form-control mb-3" required>

          <div class="table-responsive" style="overflow-x: visible !important;">
            <table class="table table-bordered table-sm text-center mb-0" style="width: 100%; table-layout: fixed;">
              <thead class="bg-primary text-white">
                <tr>
                  <th>Tanker</th>
                  <?php foreach($depots as $d): ?>
                    <th><?= htmlspecialchars($d) ?></th>
                  <?php endforeach; ?>
                </tr>
              </thead>
              <tbody>
                <?php foreach($tankers as $t): ?>
                  <tr>
                    <td><b><?= htmlspecialchars($t) ?></b></td>
                    <?php foreach($depots as $d): ?>
                      <td>
                        <input type="checkbox"
                               name="availability[<?= $t ?>][<?= $d ?>]"
                               value="1"
                               class="availability-checkbox"
                               data-tanker="<?= $t ?>"
                               data-depot="<?= $d ?>"
                               style="transform: scale(1.1); margin: 0 auto; display: block;">
                      </td>
                    <?php endforeach; ?>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Save Changes</button>
          
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($_SESSION['role'] == "mechanic"): ?>
<div class="modal fade" id="saveChecklistModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered" style="max-width: 900px;">
    <div class="modal-content">
      <form id="saveChecklistForm" method="POST" action="save_checklist.php">
        <div class="modal-header bg-success text-white">
          <h5 class="modal-title"></i> Save Tanker Availability (Today)</h5>
          <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
        </div>

        <div class="modal-body">
          <input type="hidden" name="checklist_date" value="<?= date('Y-m-d') ?>">

          <div class="table-responsive" style="overflow-x: visible !important;">
            <table class="table table-bordered table-sm text-center mb-0" style="width: 100%; table-layout: fixed;">
              <thead class="bg-primary text-white">
                <tr>
                  <th>Tanker</th>
                  <?php foreach($depots as $d): ?>
                    <th><?= htmlspecialchars($d) ?></th>
                  <?php endforeach; ?>
                </tr>
              </thead>
              <tbody>
                <?php foreach($tankers as $t): ?>
                  <tr>
                    <td><b><?= htmlspecialchars($t) ?></b></td>
                    <?php foreach($depots as $d): ?>
                      <td>
                        <input type="checkbox"
                               name="availability[<?= $t ?>][<?= $d ?>]"
                               value="1"
                               style="transform: scale(1.1); margin: 0 auto; display: block;">
                      </td>
                    <?php endforeach; ?>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Save</button>
          
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- ✅ SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(function(){
  $('[data-toggle="tooltip"]').tooltip();

  $('#checklist_date').on('change',function(){
    let d=$(this).val();
    if(!d)return;
    fetch('load_checklist.php?date='+d)
      .then(r=>r.json()).then(data=>{
        $('.availability-checkbox').each(function(){
          let t=$(this).data('tanker'),dep=$(this).data('depot');
          $(this).prop('checked',!!(data[t]&&data[t][dep]));
        });
      });
  });

  $('#editChecklistForm, #saveChecklistForm').on('submit', function(e){
  e.preventDefault();
  let form = this;

  Swal.fire({
    title: 'Confirm Save',
    text: 'Are you sure you want to save these changes?',
    icon: 'question',
    showCancelButton: true,
    confirmButtonText: 'Yes, Save',
    cancelButtonText: 'Cancel',
    confirmButtonColor: '#28a745',
    cancelButtonColor: '#6c757d'
  }).then((result) => {
    if (result.isConfirmed) {
      fetch('save_checklist.php', { method: 'POST', body: new FormData(form) })
        .then(r => r.json())
        .then(data => {
          if(data.success){
            Swal.fire({
              icon: 'success',
              title: 'Saved Successfully!',
              text: data.message,
              showConfirmButton: false,
              timer: 1800
            }).then(() => location.reload());
          } else {
            Swal.fire({
              icon: 'error',
              title: 'Failed to Save',
              text: data.message || 'Something went wrong!',
              confirmButtonColor: '#d33'
            });
          }
        })
        .catch(() => {
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Unable to connect to server.'
          });
        });
    }
  });
});


});
</script>
</body>
</html>
