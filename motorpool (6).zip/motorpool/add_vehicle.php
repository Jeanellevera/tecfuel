<?php
include "DB_connection.php";

$tanker_code = trim($_POST['tanker_code']);
$plate_no    = trim($_POST['plate_no']);
$category    = trim($_POST['category']);
$active      = isset($_POST['active']) ? (int)$_POST['active'] : 1;

// auto-sync enum status
$status = ($active == 1) ? 'active' : 'inactive';

try {
    $stmt = $conn->prepare("
        INSERT INTO vehicles (tanker_code, plate_no, category, active, status)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$tanker_code, $plate_no, $category, $active, $status]);

    echo json_encode(['success' => true, 'message' => 'Vehicle added successfully!']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
