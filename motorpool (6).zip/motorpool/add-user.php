<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

include "../DB_connection.php";

try {
    $full_name = trim($_POST['full_name'] ?? '');
    $username  = trim($_POST['username'] ?? '');
    $password  = trim($_POST['password'] ?? '');
    $role      = strtolower(trim($_POST['role'] ?? ''));
    $status    = strtolower(trim($_POST['status'] ?? ''));

    // ✅ Validate input
    if ($full_name === '' || $username === '' || $password === '' || $role === '') {
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit;
    }

    // ✅ Validate role (must be in ENUM)
    $validRoles = ['admin', 'driver', 'mechanic', 'warehouse'];
    if (!in_array($role, $validRoles)) {
        echo json_encode(['success' => false, 'message' => 'Invalid role value.']);
        exit;
    }

    // ✅ Check for duplicate username
    $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $check->execute([$username]);
    if ($check->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Username already exists.']);
        exit;
    }

    // ✅ Hash password
    $hashed = password_hash($password, PASSWORD_DEFAULT);

    // ✅ Insert user
    $stmt = $conn->prepare("INSERT INTO users (full_name, username, password, role, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$full_name, $username, $hashed, $role, $status ?: 'active']);

    echo json_encode(['success' => true, 'message' => '✅ User added successfully!']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
