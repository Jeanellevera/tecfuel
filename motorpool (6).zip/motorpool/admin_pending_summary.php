<?php
include "DB_connection.php";

$start = $_GET['start_date'] ?? date('Y-m-01');
$end   = $_GET['end_date']   ?? date('Y-m-d');

$stmt = $conn->prepare("
  SELECT DATEDIFF(NOW(), wo.request_date) AS pending_days
  FROM work_orders wo
  WHERE wo.status = 'Pending'
  AND DATE(wo.request_date) BETWEEN :start AND :end
");
$stmt->execute(['start' => $start, 'end' => $end]);
$rows = $stmt->fetchAll(PDO::FETCH_COLUMN);

$total = count($rows);
$longest = $total > 0 ? max($rows) : 0;
$average = $total > 0 ? round(array_sum($rows) / $total, 1) : 0;

header('Content-Type: application/json');
echo json_encode([
  'total' => $total,
  'longest' => $longest,
  'average' => $average
]);
?>
